# -*- coding: utf-8 -*-
import os
from flask import Flask
from flask.ext.login import LoginManager
							 
app = Flask(__name__)
login_manager = LoginManager()
login_manager.setup_app(app)

import ws.server
