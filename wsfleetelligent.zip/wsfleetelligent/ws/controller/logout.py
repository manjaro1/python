# -*- coding: utf-8 -*-
from xml.dom.minidom import parse, parseString
from ws.model import database as d

"""_____________________________________________________________________________________________________________
# CLASE LOGOUT
# 
#_______________________________________________________________________________________________________________
"""
class Logout:
		
	def __init__(self, userid, tipo):
		self.formato = tipo
		self.usuario = userid
		self.tabla = 'cuentas'
		self.campos = '*'
		self.valores = []
											 
	
	def salir(self):
		if self.formato == 1:											#____XML____
			try:																			
				datos = "sesion_token = Null"
				where = " WHERE id_usuario='" + str(self.usuario) + "'"
				db = d.Database(self.tabla,self.usuario,self.campos)
				respuesta = db.modificar(datos,where)				
				self.valores = "Finalizado"
				return True
			except:
				return False									
		elif self.formato == 2:											#____JSON____
			msg = 'json'
			return True
		else:
			return False	
