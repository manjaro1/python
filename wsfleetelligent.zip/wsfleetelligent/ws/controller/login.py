# -*- coding: utf-8 -*-
from xml.dom.minidom import parse, parseString
from ws.model import database as d

class Login:	
	def __init__(self,datos,modo,tipo):
		self.contenido = datos
		self.modo_login = modo
		self.tipo_dato = tipo		
		self.credenciales = []
		self.datos_acceso = None			
	
	def is_valid(self):
		if self.tipo_dato==1:							#____XML____			
			try:				#Intentar obtener todos los datos necesarios para autenticar al usuario								
				lista = self.contenido.getElementsByTagName('credenciales')[0]
				total_credenciales = 0							
				valores = lista.getElementsByTagName('c')
				for valor in valores:
					total_credenciales = total_credenciales + 1
					datos=valor.childNodes					
					for dato in datos:
						if dato.nodeType == dato.TEXT_NODE:							
							self.credenciales.append(dato.data)																							
			except:				#Si no se pueden obtener las credenciales necesarias
				return False 
			else:				#Validar los datos del usuario
				exito = self.autenticar_datos()				
				return exito	#True o False
		elif self.tipo_dato==2:							#____JSON____
			return True
		else:											#____TIPO DE DATO NO RECONOCIDO____
			return False		

	def autenticar_datos(self):		
		Switch = {1:self.podometro_login(),\
				  2:self.calori_login(),\
				  3:self.user_password_login(),\
				  4:self.servicio_vinculado_login()
				  }		
		case=int(self.modo_login)
		resultado = Switch[case]		
		return resultado
		

	def podometro_login(self):
		id_podometro= self.credenciales[0]
		tabla = 'cuentas'
		id_u = ''
		campos = 'id_usuario,usuario,contrasenia'	
		where = " WHERE id_podometro='" + id_podometro + "'"
		db = d.Database(tabla,id_u,campos)
		respuesta = db.get(where)
		if respuesta == True:		#Podometro vinculado
			self.datos_acceso = {'username':db.rows[0]['usuario'],'userid':db.rows[0]['id_usuario'],'userpwd':db.rows[0]['contrasenia'],'estado':'vinculado'}
			return True
		else:						
			return False			#Podometro no vinculado o inexistente
 
	def calori_login(self):
		id_calori= self.credenciales[0]
		tabla = 'calori'
		id_u = ''
		campos = 'id_usuario,estado'	
		where = " WHERE id_calori='" + id_calori + "'"
		db = d.Database(tabla,id_u,campos)
		respuesta = db.get(where)
		if respuesta == True:		#Calori registrado
			user_actual = int(db.rows[0]['id_usuario'])
			estado = int(db.rows[0]['estado'])
			if user_actual != 0 and user_actual != None:
				tabla = 'cuentas'
				id_u = ''
				campos = 'id_cuenta,usuario,contrasenia'
				where = " WHERE id_usuario='" + str(user_actual) + "'"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if respuesta == True:
					self.datos_acceso = {'username':db.rows[0]['usuario'],'userid':user_actual,'userpwd':db.rows[0]['contrasenia'],'estado':estado}
					return True		#Calori vinculado
				else:
					return '0'		#Calori no vinculado
			else:
				 return '0'			#Calori no vinculado a algun usuario			
		else:						
			return False			#Calori no registrado
 
	def user_password_login(self):
		try:
			usuario = self.credenciales[0]
			contrasenia = self.credenciales[1]
			tabla = 'cuentas'
			id_u = ''
			campos = 'id_usuario,usuario,contrasenia'	
			where = " WHERE usuario='" + usuario + "' AND contrasenia='" + contrasenia +"'"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if respuesta == True:		#Usuario registrado
				self.datos_acceso = {'username':db.rows[0]['usuario'],'userid':db.rows[0]['id_usuario'],'userpwd':db.rows[0]['contrasenia'],'estado':'activo'}
				return True
			else:
				return False
		except:						
			return False				#Usuario no registrado		
		
	def servicio_vinculado_login(self): #recibir api, token del usuario
		try:
			token = self.credenciales[0]			
			tabla = 'servicio_vinculado'
			id_u = ''
			campos = 'id_usuario,id_servicio'	
			where = " WHERE token='" + token + "'"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if respuesta == True:		#Si existe la vinculacion con algun servicio
				user_actual = int(db.rows[0]['id_usuario'])
				tabla = 'cuentas'
				id_u = ''
				campos = 'id_cuenta,usuario,contrasenia'
				where = " WHERE id_usuario='" + str(user_actual) + "'"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if respuesta == True:
					self.datos_acceso = {'username':db.rows[0]['usuario'],'userid':user_actual,'userpwd':db.rows[0]['contrasenia'],'estado':'vinculado'}
					return True			
				else:
					return False		#No se encuentra el usuario
			else:
				return False			#No se encuentra el usuario
		except:						
			return False				#No se ha podido realizar la consulta
