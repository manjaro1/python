# -*- coding: utf-8 -*-
import os, random, string
import time
import datetime
import unicodedata
import re
from numpy import *
from ordereddict import OrderedDict
from math import fabs
from ws.model import database as d
from ws.libraries import security as s


class Vehiculo:

	def __init__(self, imei, tipo):
		self.vehiculoid = None
		self.imeid = None
		self.imei = imei
		self.formato = tipo
		self.valores = []

	def obtener_coordenadas(self):
		if self.formato == 1:
			try:
				tabla = 'imei_id_catalog'
				usuario = ''
				campos = 'id'
				where = " WHERE imei='" + str(self.imei) + "'"
				db = d.Database(tabla,usuario,campos)
				respuesta = db.get(where)
				if respuesta == True:
					self.imeid = db.rows[0]['id']
					tabla = 'ruphistory_data'
					usuario = ''
					campos = 'timestamp, longitude, latitude'
					where = " where id_imei='" + str(self.imeid) + "'"
					db = d.Database(tabla,usuario,campos)
					respuesta = db.get(where)
					longitud = int(db.rows[0]['longitude'])
					latitud = int(db.rows[0]['latitude'])
					if(longitud != None and latitud != None):
                                        	longitud = longitud / 10000000.0
                                                latitud = latitud / 10000000.0
						self.valores = {'imei':self.imei,'timestamp':db.rows[0]['timestamp'],'longitude':longitud,'latitude':latitud}
				#	return True
					return True
				else:
					return False
			except:
				self.valores = ['Sin valores para este elemento']
				return True
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False
			
	def obtener_coordenadas_grupo(self,grupo,subgrupo):
		if self.formato == 1:
			try:
				tabla = 'asignacion_vehiculo'
				usuario = ''
				campos = 'id_vehiculo'
				#where = " WHERE id_grupo='" + str(grupo) + "' AND id_subgrupo='" + str(subgrupo) + "'"
				where = " WHERE id_grupo='" + str(grupo) + "'"
				db = d.Database(tabla,usuario,campos)
				respuesta = db.get(where)
				if respuesta == True:
					numfilas = db.numfilas
					vector = []
					i = 0
					while i < numfilas:
						vehiculoid = db.rows[i]['id_vehiculo']				
						tabla = 'imei_id_catalog i, vehiculo v'
						usuario = ''
						campos = 'i.imei,v.id_imei'
						where = " where v.id_vehiculo='" + str(vehiculoid) + "' AND v.id_imei=i.id"
						db0=d.Database(tabla,usuario,campos)						
						respuesta0 = db0.get(where)
						imei = db0.rows[0]['imei']
						imeid = db0.rows[0]['id_imei']
						
						tabla = 'ruphistory_data'
						usuario = ''
						campos = 'timestamp, longitude, latitude'
						where = " where id_imei='" + str(imeid) + "'"
						db1=d.Database(tabla,usuario,campos)						
						respuesta1 = db1.get(where)
						longitud = db1.rows[0]['longitude']
                                                latitud = db1.rows[0]['latitude']
						if(longitud != None and latitud != None):
							longitud = longitud / 10000000.0
							latitud = latitud / 10000000.0
							vector.append({'imei':imei,'timestamp':db1.rows[0]['timestamp'],'longitude':longitud,'latitude':latitud})						
							i = i + 1
					self.valores = vector						
					return True
				else:
					return False
			except:
				return False
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False
			
	def datos_accion(self,operacion):
		if self.formato == 1:
			#try:
			if (operacion == '1'):
				resultado = self.consultar_vehiculo_independiente()
			elif (operacion == '2'):
				resultado = self.consultar_vehiculo()
			elif (operacion == '3'):
				resultado = self.consultar_vehiculo_cuestionario()
			elif (operacion == 'km'):
				resultado = self.consultar_vehiculo_kilometraje()
			return resultado
			#except:
			#	return False
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#1
	def consultar_vehiculo_independiente(self):	
		try:
			contenido = self.imei
			serie = contenido.getElementsByTagName('serie')[0].firstChild.data
			#clienteid = contenido.getElementsByTagName('clienteid')[0].firstChild.data
			
			#tabla = 'fleetelligent.vehiculo v,public.auto a,public.linea l,public.marca m'
			tabla = 'fleetelligent.vehiculo v,comun.auto a,comun.marca m,fleetelligent.tipovehiculo t'
			id_u = ''
			campos = 'v.idvehiculo,v.idcliente,v.idtipovehiculo,v.nombre,v.placa,a.nombre as nombreauto,a.idcategoriaauto,m.nombre as nombremarca,t.nombre as nombretipo'
			where = " WHERE v.numserie='" + str(serie) + "' AND v.activo=TRUE AND v.idtipovehiculo=t.idtipovehiculo AND v.idauto=a.idauto AND a.idmarca=m.idmarca"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			
			if(respuesta == True):
				#if(clienteid == str(db.rows[0]['idcliente'])):
				idcategoriaauto = db.rows[0]['idcategoriaauto']
				siglas = {1:'AUTO',2:'CAMIONETA'}
				siglasauto = siglas[int(idcategoriaauto)]
				self.valores = {'idvehiculo':db.rows[0]['idvehiculo'],'serie':str(serie),'idtipovehiculo':db.rows[0]['idtipovehiculo'],'tipovehiculo':db.rows[0]['nombretipo'],'nombre':db.rows[0]['nombre'],'marca':db.rows[0]['nombremarca'],'auto':db.rows[0]['nombreauto'],'placa':db.rows[0]['placa'],'idcliente':db.rows[0]['idcliente'],'siglascategoriaauto':siglasauto}
				return True
				#else:
				#	self.valores = "No hubo coincidencia con el ID de cliente proporcionado!"
				#return '1'
			else:
				self.valores = "El vehiculo no existe o se encuentra inactivo!"
				return '2'
		except:
			self.valores = "Datos incorrectos!"
			return '2'

	#2
	def consultar_vehiculo(self):
		try:
			contenido = self.imei
			serie = contenido.getElementsByTagName('serie')[0].firstChild.data
			clienteid = contenido.getElementsByTagName('clienteid')[0].firstChild.data

			tabla = 'fleetelligent.vehiculo v,public.auto a,public.linea l,public.marca m'
			id_u = ''
			campos = 'v.idvehiculo,v.numserie,v.nombre as nombrevehiculo,v.idtipovehiculo,l.nombre as nombrelinea,m.nombre as nombremarca'
			where = " WHERE v.numserie='" + str(serie) + "' AND v.idcliente='" + str(clienteid) + "' AND v.activo=TRUE AND v.idauto=a.idauto AND a.idlinea=l.idlinea AND l.idmarca=m.idmarca"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			
			#Buscar si existe solicitud del vehiculo sin finalizar
			tabla1 = 'fleetelligent.vehiculo v,fleetelligent.solicitudserviciovehiculo s'
			id_u1 = ''
			campos1 = 's.idsolicitudserviciovehiculo'
			where1 = " WHERE v.numserie='" + str(serie) + "' AND v.idvehiculo=s.idvehiculo AND s.idetapa<>2 AND s.activo=TRUE"
			db1 = d.Database(tabla1,id_u1,campos1)
			respuesta1 = db1.get(where1)
			
			#respuesta1 = False
			if(respuesta1 == True):
				self.valores = "Existe una solicitud del vehiculo sin finalizar. La solicitud no puede ser completada!"
				return '1'

			if(respuesta == True): #Si vehiculo existe y se encuentra activo
				vehiculoid = db.rows[0]['idvehiculo']
				vehiculoserie = db.rows[0]['numserie']
				vehiculonombre = db.rows[0]['nombrevehiculo']
				vehiculotipo = db.rows[0]['idtipovehiculo']
				linea = db.rows[0]['nombrelinea']
				marca = db.rows[0]['nombremarca']
			
				chofer_actual = "N/A"
				tabla = 'fleetelligent.asignacionvehiculo a, fleetelligent.chofer c,comun.persona p'
				campos = 'p.nombre,p.apellidopaterno,p.apellidomaterno'
				where = " WHERE a.idvehiculo='" + str(vehiculoid) + "' AND a.idchofer=c.idchofer AND c.idpersona=p.idpersona AND NOW()>a.fechasalida AND NOW()<a.fecharecepcion  ORDER BY a.idasignacionvehiculo DESC"			
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True): # Si el vehiculo tiene chofer asignado
					n = ""
					ap = ""
					am = ""
					if(db.rows[0]['nombre']!=None):
						n = unicode(db.rows[0]['nombre'],'utf-8')
						n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
					if(db.rows[0]['apellidopaterno']!=None):
						ap = unicode(db.rows[0]['apellidopaterno'],'utf-8')
						ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
					if(db.rows[0]['apellidomaterno']!=None):
						am = unicode(db.rows[0]['apellidomaterno'],'utf-8')
						am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')
					chofer_actual = n + ' ' + ap + ' ' + am
			
				idsolicitudsv = "N/A"
				tabla = 'fleetelligent.solicitudserviciovehiculo s,fleetelligent.flujo f,fleetelligent.etapa e,usuario.modulo m'
				campos = 's.idsolicitudserviciovehiculo'
				where = " WHERE s.idvehiculo='" + str(vehiculoid) + "' AND s.activo=TRUE"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True):    # Si el vehiculo tiene idsolicitudserviciovehiculo
					idsolicitudsv = db.rows[0]['idsolicitudserviciovehiculo']
			
				choferes_disponibles = "N/A"
				tabla = 'fleetelligent.chofertipovehiculo t,fleetelligent.chofer c,comun.persona p'
				campos = 'p.nombre,p.apellidopaterno,p.apellidomaterno,c.idchofer'
				where = " WHERE t.idtipovehiculo='" + str(vehiculotipo) + "' AND t.idchofer=c.idchofer AND c.idpersona=p.idpersona ORDER BY c.idchofer"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True):    # Si el vehiculo tiene choferes disponibles
					numfilas = db.numfilas
					vector = []
					i = 0
					while i < numfilas:
						n = ""
						ap = ""
						am = ""
						if(db.rows[i]['nombre']!=None):
							n = unicode(db.rows[i]['nombre'],'utf-8')
							n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
						if(db.rows[i]['apellidopaterno']!=None):
							ap = unicode(db.rows[i]['apellidopaterno'],'utf-8')
							ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
						if(db.rows[i]['apellidomaterno']!=None):
							am = unicode(db.rows[i]['apellidomaterno'],'utf-8')
							am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')
						nombre = n + ' ' + ap + ' ' + am
					
						vector.append({'Chofer_ID':db.rows[i]['idchofer'],'Nombre_Chofer':nombre})						
						i = i + 1
					choferes_disponibles = vector
			
				self.valores = {'vehiculoid':vehiculoid,'Vehiculo_NoSerie':vehiculoserie,'Tipo_Vehiculo_ID':vehiculotipo,'Nombre_Vehiculo':vehiculonombre,'Marca_Nombre':marca,'Linea_Nombre':linea,'Personal_Asignado':chofer_actual,'Solicitud_Servicio_Vehiculo_ID':idsolicitudsv,'Lista_Choferes':choferes_disponibles}
				return True
			else:
				self.valores = "No existe vehiculo para el cliente proporcionado o se encuentra inactivo!"
				return '1'
		except:
			self.valores = "Datos incorrectos. Revise!"
			return '2' #Usuario no existe o esta inactivo

	#3
	def consultar_vehiculo_cuestionario(self):	
		#xy = 1
		#if xy == 1:
		try:
			contenido = self.imei
			vehiculoid = contenido.getElementsByTagName('vehiculoid')[0].firstChild.data
			clienteid = contenido.getElementsByTagName('clienteid')[0].firstChild.data
			valor_i = 'ASIG'
			valor_f = 'RUTA'
			#Busqueda de registro con el idvehiculo e idcliente proporcionados
			tabla = 'fleetelligent.vehiculo v,public.auto a'
			id_u = ''
			campos = 'v.idvehiculo,v.idauto'
			where = " WHERE v.idvehiculo=" + str(vehiculoid) + " AND v.idcliente=" + str(clienteid) + " AND v.activo=True AND v.idauto=a.idauto"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			#Busqueda en la tabla asignacionvehiculo si existe un registro para el vehículo y el cliente dado y que la
			#solicitud relacionada se encuentre en cualquiera de las etapas obtenidas anteriormente.
			if(respuesta == True):
				idauto = db.rows[0]['idauto']
				tabla = 'fleetelligent.asignacionvehiculo a,fleetelligent.etapa e,fleetelligent.chofer c,comun.solicitud s,comun.persona p'
				id_u = ''
				campos = 'a.idasignacionvehiculo,a.idchofer,e.idetapa,e.nombre,e.siglas,p.nombre as personanombre,p.apellidopaterno,p.apellidomaterno'
				where = " WHERE a.idvehiculo=" + str(vehiculoid) + " AND a.activo=True AND a.idsolicitud>0 AND a.idsolicitud=s.idsolicitud AND a.idchofer=c.idchofer AND c.activo=True AND c.idpersona=p.idpersona AND s.activo=True AND s.idetapa=e.idetapa AND (e.siglas='ASIG' OR e.siglas='RUTA')"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True):
					n = ""
					ap = ""
					am = ""
					if(db.rows[0]['personanombre']!=None):
						n = unicode(db.rows[0]['personanombre'],'utf-8')
						n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
					if(db.rows[0]['apellidopaterno']!=None):
						ap = unicode(db.rows[0]['apellidopaterno'],'utf-8')
						ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
					if(db.rows[0]['apellidomaterno']!=None):
						am = unicode(db.rows[0]['apellidomaterno'],'utf-8')
						am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')
					nombre = n + ' ' + ap + ' ' + am
					
					idasig = db.rows[0]['idasignacionvehiculo']
					idchofer = db.rows[0]['idchofer']
					etapaid = db.rows[0]['idetapa']
					etapanombre = db.rows[0]['nombre']
					etapasiglas = db.rows[0]['siglas']
					#_______Hallar el cuestionario
					if etapanombre == 'ASIGNADO':
						inspecciontipo = 'INSPENTGA'
					elif etapanombre == 'RUTA':
						inspecciontipo = 'INSPDEVOL'
					
					tabla = 'inspeccion.autoclientecuestionariopregunta accp ,inspeccion.pregunta p,inspeccion.tiporespuesta tr,\
							 inspeccion.autocliente ac,inspeccion.cuestionario c,inspeccion.tipoinspeccion ti'
					id_u = 'c.idcuestionario,c.cuestionario,c.siglas as siglascuestionario,c.orden as ordencuestionario,ti.idtipoinspeccion,\
							ti.tipoinspeccion,ti.siglas as siglastipoinspeccion,p.idpregunta,p.pregunta,p.siglas as siglaspregunta,\
							tr.siglas as siglastiporespuesta,tr.idtiporespuesta, accp.orden as ordenpregunta'
					campos = 'accp.idautoclientecuestionariopregunta,c.idcuestionario,c.cuestionario,c.siglas as siglascuestionario,c.orden as ordencuestionario,ti.idtipoinspeccion,\
							  ti.tipoinspeccion,ti.siglas as siglastipoinspeccion,p.idpregunta,p.pregunta,p.siglas as siglaspregunta,\
							  tr.siglas as siglastiporespuesta,tr.idtiporespuesta, accp.orden as ordenpregunta '
					where = " WHERE ac.idauto=" + str(idauto) + " AND ac.idcliente=" + str(clienteid) + " AND ti.siglas LIKE '" + str(inspecciontipo) + "%' \
							  AND p.idpregunta=accp.idpregunta AND p.activo=True AND tr.idtiporespuesta = p.idtiporespuesta AND tr.activo=True AND \
							  ac.idautocliente=accp.idautocliente AND ac.activo=True AND c.idcuestionario = accp.idcuestionario AND c.activo=True AND \
							  ti.idtipoinspeccion = c.idtipoinspeccion AND ti.activo=True"
					db = d.Database(tabla,id_u,campos)
					respuesta = db.get(where)
					cuestionariodata = []
					if(respuesta == True):
						numfilas = db.numfilas
						i = 0
						while i < numfilas:
							
							idcuestionario = db.rows[i]['idcuestionario']
							cuestionario = unicode(db.rows[i]['cuestionario'],'utf-8')
							cuestionario = unicodedata.normalize('NFKD', cuestionario).encode('ascii','ignore')
							siglascuestionario = db.rows[i]['siglascuestionario']
							ordencuestionario = db.rows[i]['ordencuestionario']
							idtipoinspeccion = db.rows[i]['idtipoinspeccion']
							tipoinspeccion = db.rows[i]['tipoinspeccion']
							siglastipoinspeccion = db.rows[i]['siglastipoinspeccion']
							idpregunta = db.rows[i]['idpregunta']
							pregunta = unicode(db.rows[i]['pregunta'],'utf-8')
							pregunta = unicodedata.normalize('NFKD', pregunta).encode('ascii','ignore')
							siglaspregunta = db.rows[i]['siglaspregunta']
							siglastiporespuesta = db.rows[i]['siglastiporespuesta']
							idtiporespuesta = db.rows[i]['idtiporespuesta']
							ordenpregunta = db.rows[i]['ordenpregunta']
							
							cuestionariodata.append({'idcuestionario':idcuestionario,'cuestionario':cuestionario,'siglascuestionario':siglascuestionario,'ordencuestionario':ordencuestionario,'idtipoinspeccion':idtipoinspeccion,'tipoinspeccion':tipoinspeccion,'siglastipoinspeccion':siglastipoinspeccion,'idpregunta':idpregunta,'pregunta':pregunta,'siglaspregunta':siglaspregunta,'siglastiporespuesta':siglastiporespuesta,'idtiporespuesta':idtiporespuesta,'ordenpregunta':ordenpregunta})
							i = i + 1
						asignacion_data = OrderedDict([('asignacionid',idasig),('autoid',idauto),('etapaid',etapaid),('etapanombre',etapanombre),('etapasiglas',etapasiglas),('choferid',idchofer),('persona',nombre),('cuestionarios',cuestionariodata)])
						self.valores = asignacion_data
					return True
				else:
					self.valores = "No se encontraron solicitudes para los datos proporcionados!"
					return '2'
			else:
				self.valores = "No hubo coincidencias con los datos proporcionados!"
				return '2'
		except:
			self.valores = "Datos incorrectos!"
			return '1'


	#km
	def consultar_vehiculo_kilometraje(self):	
		try:
			contenido = self.imei
			vehiculoid = contenido.getElementsByTagName('vehiculoid')[0].firstChild.data
			qry = "SELECT tabla.respuesta FROM((SELECT id.idinspecciondetalle,id.fechacreacion as fecha,id.respuesta FROM inspeccion.inspecciondetalle id,inspeccion.inspeccion i WHERE i.idinspeccion=id.idinspeccion AND i.idvehiculo="+str(vehiculoid)+" AND id.siglaspregunta like 'A' ORDER BY id.fechacreacion DESC LIMIT 1) UNION (SELECT id.idinspecciondetalle,id.fechamodificacion as fecha,id.respuesta FROM inspeccion.inspecciondetalle id,inspeccion.inspeccion i WHERE i.idinspeccion=id.idinspeccion AND i.idvehiculo="+str(vehiculoid)+" AND id.siglaspregunta like 'A' ORDER BY id.fechamodificacion DESC LIMIT 1)) AS tabla ORDER BY fecha DESC LIMIT 1"
			tabla = "1"
			id_u= "1"
			campos = "1"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.query(qry)
			if(respuesta == True):
				#self.valores = qry
				self.valores=db.rows[0]['respuesta']
				return True
			else:
				self.valores = "No se pudo completar la solicitud!"
				return '2'
		except:
			self.valores = "Datos incorrectos!"
			return '2'


	def actualizar_datos(self,datos):
		exito = False
		return exito
		
		
	def nueva_inspeccion(self,datos):
		campos = []
		if self.formato == 1:
			try:
				values = datos.getElementsByTagName('values')[0]
				total_values = 0							
				valores = values.getElementsByTagName('c')
				for valor in valores:
					total_values = total_values + 1
					datos=valor.childNodes					
					for dato in datos:
						if dato.nodeType == dato.TEXT_NODE:							
							campos.append(dato.data)														
				if(total_values >= 2):								
					id_inspector = campos[0]
					id_usuario = campos[1]
					id_vehiculo = campos[2]
					kilometraje = campos[3]				
					nivel_aceite = campos[4]
					nivel_anticongelante = campos[5]
					nivel_liqfrenos = campos[6]
					nivel_liqservodireccion = campos[7]
					cinturon = campos[8]
					pedal_clutch = campos[9]
					pedal_freno = campos[10]
					juego_direccion = campos[11]
					claxon = campos[12]
					intermitentes = campos[13]
					luces = campos[14]
					neu_delanteros = campos[15]
					neu_traseros = campos[16]
					neu_repuesto = campos[17]
					vista_frontal = campos[18]
					vista_posterior = campos[19]
					vista_lateral_izq = campos[20]
					vista_lateral_der = campos[21]
					observaciones = campos[22]
					fecha = campos[23]
					#fecha = time.strptime(campos[23], "%d/%m/%Y")

					values = str(id_inspector) + "," + str(id_usuario) + "," + str(id_vehiculo) + "," + str(kilometraje) + ",date('" + str(fecha) + "')," + str(nivel_aceite) + \
						"," + str(nivel_anticongelante) + "," + str(nivel_liqfrenos) + "," + str(nivel_liqservodireccion) + "," + str(cinturon) + "," + str(pedal_clutch) + \
						"," + str(pedal_freno) + "," + str(juego_direccion) + "," + str(claxon) + "," + str(intermitentes) + "," + str(luces) + "," + str(neu_delanteros) + \
						"," + str(neu_traseros) + "," + str(neu_repuesto) + "," + str(vista_frontal) + "," + str(vista_posterior) + "," + str(vista_lateral_izq) + \
						"," + str(vista_lateral_der) + ",'" + str(observaciones) + "'"

					tabla = 'inspeccion'
					id_u = ''
					campos = 'id_inspector,id_usuario,id_vehiculo,kilometraje,fecha_inspeccion,nivel_aceite,nivel_anticongelante,nivel_liqfrenos,nivel_liqservodireccion,cinturon,\
							pedal_clutch,pedal_freno,juego_direccion,claxon,intermitentes,luces,neu_delanteros,neu_traseros,neu_repuesto,vista_frontal,vista_posterior,\
							vista_lateral_izq,vista_lateral_der,observaciones'
					db = d.Database(tabla,id_u,campos)
					respuesta = db.agregar(values)
					if respuesta ==True:				
						self.valores = 'Datos almacenados correctamente'
						return True				
					else:					
						return False
				else:
					return False
			except:
				return False
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	def inspeccion_accion(self,operacion):
		if self.formato == 1:
			try:
				if (operacion == '1'):
					resultado = self.f_nueva_inspeccion()
				elif (operacion == '2'):
					resultado = self.f_consultar_inspeccion()
				return resultado
			except:
				self.informe = "No se pudo completar la solicitud."
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False
		
	def f_nueva_inspeccion(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			idcliente = int(datos.getElementsByTagName('a')[0].firstChild.data)
			idusuario = int(datos.getElementsByTagName('b')[0].firstChild.data)
			idvehiculo = int(datos.getElementsByTagName('c')[0].firstChild.data)
			idtservicio = int(datos.getElementsByTagName('d')[0].firstChild.data)
			try:
				idetapa = int(datos.getElementsByTagName('e')[0].firstChild.data)
			except:
				idetapa = 2
			try:
				idssvehiculo = int(datos.getElementsByTagName('f')[0].firstChild.data)
			except:
				idssvehiculo = None
			kilometraje = int(datos.getElementsByTagName('g')[0].firstChild.data)
			cinturon = datos.getElementsByTagName('h')[0].firstChild.data
			pedalclutch = datos.getElementsByTagName('i')[0].firstChild.data
			pedalfreno = datos.getElementsByTagName('j')[0].firstChild.data
			juegodireccion = datos.getElementsByTagName('k')[0].firstChild.data
			claxon = datos.getElementsByTagName('l')[0].firstChild.data
			intermitente = datos.getElementsByTagName('m')[0].firstChild.data
			luces = datos.getElementsByTagName('n')[0].firstChild.data
			neudelanteros = datos.getElementsByTagName('o')[0].firstChild.data
			neutraseros = datos.getElementsByTagName('p')[0].firstChild.data
			neurepuesto = datos.getElementsByTagName('q')[0].firstChild.data
			try:
				observaciones = datos.getElementsByTagName('r')[0].firstChild.data
			except:
				observaciones = ' '
			nivelaceite = datos.getElementsByTagName('s')[0].firstChild.data
			nanticongelante = datos.getElementsByTagName('t')[0].firstChild.data
			nliquidodir = datos.getElementsByTagName('u')[0].firstChild.data
			nliquidofr = datos.getElementsByTagName('v')[0].firstChild.data
			aceiteagregado = int(datos.getElementsByTagName('w')[0].firstChild.data)
			antagregado = int(datos.getElementsByTagName('x')[0].firstChild.data)
			liquidodiragregado = int(datos.getElementsByTagName('y')[0].firstChild.data)
			liquidofragregado = int(datos.getElementsByTagName('z')[0].firstChild.data)
			acelerador = datos.getElementsByTagName('aa')[0].firstChild.data
			vistafrontal = datos.getElementsByTagName('bb')[0].firstChild.data
			vistaposterior = datos.getElementsByTagName('cc')[0].firstChild.data
			vistalderecha = datos.getElementsByTagName('dd')[0].firstChild.data
			vistalizquierda = datos.getElementsByTagName('ee')[0].firstChild.data
			fechainspeccion = datos.getElementsByTagName('ff')[0].firstChild.data
			try:
				idchofer = int(datos.getElementsByTagName('gg')[0].firstChild.data)
			except:
				idchofer = 1
			
			#Buscar si existe solicitud de servicio express del vehiculo en la misma fecha de inspeccion enviada
			id_u = ''
			tabla = 'fleetelligent.solicitudserviciovehiculo v,fleetelligent.solicitudservicioexpress e'
			campos = 'v.idsolicitudserviciovehiculo'
			where = " WHERE v.idvehiculo='" + str(idvehiculo) + "' AND e.fechainspeccion='" + str(fechainspeccion) + "' AND v.idsolicitudserviciovehiculo=e.idsolicitudserviciovehiculo"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)

			if(respuesta == False):
				existe_express = False
			else:
				self.informe = 'La Solicitud de servicio express ya existe. Los datos no fueron almacenados'
				return '3'
				
			exito = '0'
			#Si se envia solicitud de servicio y si no existe solicitud express del vehiculo en la fecha de inspeccion enviada
			if(idssvehiculo != None and existe_express == False): #Si ya se tiene una solicitud de servicio
				id_u = ''
				tabla = 'fleetelligent.solicitudserviciovehiculo v,fleetelligent.flujo f'
				campos = 'v.idsolicitudservicio,v.idsolicitudserviciovehiculo,v.idetapa,f.idetapasiguiente'
				where = " WHERE v.idsolicitudserviciovehiculo='" + str(idssvehiculo) + "' AND v.idvehiculo='" + str(idvehiculo) + "' AND v.activo=TRUE AND v.idetapa=f.idetapa LIMIT 1"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True):
					filas = db.numfilas
					idsolicitudserviciov = idssvehiculo
					#Actualizar Idetapa en solicitud servicio vehiculo
					tabla = 'fleetelligent.solicitudserviciovehiculo'
					campos = ''
					datau = "idetapa='" + str(db.rows[0]['idetapasiguiente']) + "',fechamodificacion=NOW()"
					where = " WHERE idsolicitudserviciovehiculo='" + str(idsolicitudserviciov) + "'"
					db = d.Database(tabla,id_u,campos)
					respuesta = db.modificar(datau,where)
					if(respuesta == True):
						exito = '1'
					self.informe = "Solicitud de servicio de vehiculo actualizada. "
				else:
					self.informe = "La Solicitud de servicio de vehiculo se encuentra inactiva o sin etapa siguiente. "
					return '1'
					
			elif(existe_express == False):
				#Crear un registro de solicitud servicio
				tabla = 'fleetelligent.solicitudservicio'
				id_u = ''
				campos = 'idcliente,idusuario,activo,fechacreacion,fechamodificacion'
				values = str(idcliente) + "," + str(idusuario) + ",TRUE,NOW(),NOW()"
				db = d.Database(tabla,id_u,campos)
				returning = " RETURNING idsolicitudservicio"
				respuesta = db.add(values,returning)
				idsolicitudserv = db.row[0]['idsolicitudservicio']
				
				#Buscar idetapasiguiente para colocar como idetapa de solicitud servicio vehiculo
				id_u = ''
				tabla = 'fleetelligent.flujo f,fleetelligent.etapa e,usuario.modulo m'
				campos = 'f.idetapasiguiente'
				where = " WHERE f.idmodulo=m.idmodulo AND f.idetapa=e.idetapa AND m.siglas='INSPEXPRESS' AND e.inspeccion=TRUE"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				
				#Crear un registro en solicitud servicio vehiculo
				tabla = 'fleetelligent.solicitudserviciovehiculo'
				campos = 'idsolicitudservicio,idvehiculo,idtiposervicio,idetapa,activo,fechacreacion,fechamodificacion'
				values = str(idsolicitudserv) + "," + str(idvehiculo) + "," + str(idtservicio) + "," + str(db.rows[0]['idetapasiguiente']) + ",TRUE,NOW(),NOW()"
				db = d.Database(tabla,id_u,campos)
				returning = " RETURNING idsolicitudserviciovehiculo"
				respuesta = db.add(values,returning)
				idsolicitudserviciov = db.row[0]['idsolicitudserviciovehiculo']
				if(respuesta == True):
					exito = '1'
				self.informe = "Se ha creado una nueva Solicitud de servicio. "
				
			#Crear un registro en solicitud servicio expres si no existe
			if(existe_express == False and exito == '1'):
				
				campos = 'idsolicitudserviciovehiculo,kilometraje,cinturon,pedalclutch,pedalfreno,juegodireccion,claxon,intermitente,luces,neudelanteros,\
						  neutraseros,neurepuesto,observaciones,activo,fechacreacion,fechamodificacion,nivelaceite,nivelanticongelante,nivelliquidodireccion,\
						  nivelliquidofrenos,aceiteagregado,anticongelanteagregado,liquidodireccionagregado,liquidofrenosagregado,acelerador,vistafrontal,\
						  vistaposterior,vistalateralderecha,vistalateralizquierda,fechainspeccion,idchofer'
				values = str(idsolicitudserviciov) + "," + str(kilometraje) + "," + str(cinturon) + "," + str(pedalclutch) + "," + str(pedalfreno) + \
						 "," + str(juegodireccion) + "," + str(claxon) + "," + str(intermitente) + "," + str(luces) + "," + str(neudelanteros) + \
						 "," + str(neutraseros) + "," + str(neurepuesto) + ",'" + str(observaciones) + "',TRUE,NOW(),NOW()," + str(nivelaceite) + \
						 "," + str(nanticongelante) + "," + str(nliquidodir) + "," + str(nliquidofr) + "," + str(aceiteagregado) + "," + str(antagregado) + \
						 "," + str(liquidodiragregado) + "," + str(liquidofragregado) + "," + str(acelerador) + "," + str(vistafrontal) + "," + str(vistaposterior) + \
						 "," + str(vistalderecha) + "," + str(vistalizquierda) + ",'" + str(fechainspeccion) + "'," + str(idchofer)
				if(idchofer == 1):
					campos = 'idsolicitudserviciovehiculo,kilometraje,cinturon,pedalclutch,pedalfreno,juegodireccion,claxon,intermitente,luces,neudelanteros,\
							  neutraseros,neurepuesto,observaciones,activo,fechacreacion,fechamodificacion,nivelaceite,nivelanticongelante,nivelliquidodireccion,\
						      nivelliquidofrenos,aceiteagregado,anticongelanteagregado,liquidodireccionagregado,liquidofrenosagregado,acelerador,vistafrontal,\
						      vistaposterior,vistalateralderecha,vistalateralizquierda,fechainspeccion,idchofer'
					values = str(idsolicitudserviciov) + "," + str(kilometraje) + "," + str(cinturon) + "," + str(pedalclutch) + "," + str(pedalfreno) + \
						     "," + str(juegodireccion) + "," + str(claxon) + "," + str(intermitente) + "," + str(luces) + "," + str(neudelanteros) + \
						     "," + str(neutraseros) + "," + str(neurepuesto) + ",'" + str(observaciones) + "',TRUE,NOW(),NOW()," + str(nivelaceite) + \
						     "," + str(nanticongelante) + "," + str(nliquidodir) + "," + str(nliquidofr) + "," + str(aceiteagregado) + "," + str(antagregado) + \
						     "," + str(liquidodiragregado) + "," + str(liquidofragregado) + "," + str(acelerador) + "," + str(vistafrontal) + "," + str(vistaposterior) + \
							 "," + str(vistalderecha) + "," + str(vistalizquierda) + ",'" + str(fechainspeccion) + "',null"
				tabla = 'fleetelligent.solicitudservicioexpress'
				id_u = ''
				db = d.Database(tabla,id_u,campos)
				returning = " RETURNING idsolicitudservicioexpress"
				respuesta = db.add(values,returning)
				if respuesta ==True:				
					self.informe = self.informe + 'Solicitud de servicio express almacenada.'
					return True				
				else:
					self.informe = self.informe + '. No se ha podido almacenar la Solicitud de servicio express. Revise los datos enviados'
					return '2'
			else:
				self.informe = 'La Solicitud de servicio ya existe. Los datos no fueron almacenados'
				return '1'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False
			
			
	def asignacion_accion(self,operacion):
		if self.formato == 1:
			#xy=1
			#if xy==1:
			try:
				if (operacion == '1'):
					resultado = self.busqueda_asignacion_vehiculo()
				elif (operacion == '2'):
					resultado = self.busqueda_cuestionario_inspeccion_asignacion()	#....
				elif (operacion == '3'):
					resultado = self.guardar_inspeccion_asignacion()	#....
				elif (operacion == '4'):
					resultado = self.busqueda_cuestionario_inspeccion_no_asignacion()	#....
				elif (operacion == '5'):
					resultado = self.guardar_inspeccion_no_asignacion()	#....
				elif (operacion == '6'):
					resultado = self.aceptar_inspeccion_asignacion()	#....
				elif (operacion == 'busqueda'):
					resultado = self.busqueda_asignacion_folio_vehiculo()	#....
				elif (operacion == 'pendiente'):
					resultado = self.busqueda_asignacion_pendiente_fecha()	#....
				return resultado
			except:
				self.informe = "No se pudo completar la solicitud."
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#1
	def busqueda_asignacion_vehiculo(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			siglasetapa = {'ASIG':'INSPENTGA','RUTA':'INSPDEVOL',}
			folio = datos.getElementsByTagName('folio')[0].firstChild.data
			id_u = ''
			tabla = 'comun.solicitud s,comun.etapa e,fleetelligent.asignacionvehiculo av,fleetelligent.vehiculo v,comun.auto a,fleetelligent.chofer c,comun.persona p'
			campos = 's.idsolicitud,s.folio,e.idetapa,e.nombre as nombreetapa,e.siglas as siglasetapa,av.idasignacionvehiculo,\
					  av.fechasalida,av.fecharecepcion,a.idauto,a.idcategoriaauto,a.nombre as linea,v.nombre as vehiculo,v.placa,v.anio,v.numserie,\
					  v.idvehiculo,c.idchofer,p.nombre as personanombre,p.apellidopaterno,p.apellidomaterno'
			where = " WHERE s.folio=" + str(folio) + " AND s.idetapa=e.idetapa AND s.idsolicitud = av.idsolicitud AND v.idvehiculo =av.idvehiculo AND \
					  a.idauto=v.idauto AND c.idchofer = av.idchofer AND p.idpersona=c.idpersona"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				idcategoriaauto = db.rows[0]['idcategoriaauto']
				siglas = {1:'AUTO',2:'CAMIONETA'}
				siglasauto = siglas[int(idcategoriaauto)]
				
				solicitudid = str(db.rows[0]['idsolicitud'])
				folio = str(db.rows[0]['folio'])
				etapaid = str(db.rows[0]['idetapa'])
				etapa = str(db.rows[0]['nombreetapa'])
				etapasiglas = str(db.rows[0]['siglasetapa'])
				#Busqueda de tipo inspeccion con la sigla...
				if (etapasiglas in siglasetapa):
					valueetapasiglas = siglasetapa[etapasiglas]
					tabla = 'inspeccion.tipoinspeccion'
					campos = 'idtipoinspeccion'
					where = " WHERE siglas='" +str(valueetapasiglas) + "'"
					db1 = d.Database(tabla,id_u,campos)
					respuesta1 = db1.get(where)
					if(respuesta1 == True):
						idtipoinspeccion = str(db1.rows[0]['idtipoinspeccion'])
					else:
						idtipoinspeccion = "N/A"
					#
					idasignacionvehiculo = str(db.rows[0]['idasignacionvehiculo'])
					fechasalida = str(db.rows[0]['fechasalida'])
					fechaentrada = str(db.rows[0]['fecharecepcion'])
					autoid = str(db.rows[0]['idauto'])
					linea = str(db.rows[0]['linea'])
					vehiculoid = str(db.rows[0]['idvehiculo'])
					vehiculo = str(db.rows[0]['vehiculo'])
					placa = str(db.rows[0]['placa'])
					anio = str(db.rows[0]['anio'])
					numserie = str(db.rows[0]['numserie'])
					choferid = str(db.rows[0]['idchofer'])
					n = ""
					ap = ""
					am = ""
					if(db.rows[0]['personanombre']!=None):
						n = unicode(db.rows[0]['personanombre'],'utf-8')
						n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
					if(db.rows[0]['apellidopaterno']!=None):
						ap = unicode(db.rows[0]['apellidopaterno'],'utf-8')
						ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
					if(db.rows[0]['apellidomaterno']!=None):
						am = unicode(db.rows[0]['apellidomaterno'],'utf-8')
						am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')
					nombre = n + ' ' + ap + ' ' + am
					
					
					self.informe = OrderedDict([('solicitudid',solicitudid),('folio',folio),('idasignacionvehiculo',idasignacionvehiculo),('fechasalida',fechasalida),\
												('fechaentrada',fechaentrada),('etapaid',etapaid),('etapa',etapa),('etapasiglas',etapasiglas),('autoid',autoid),\
												('linea',linea),('vehiculoid',vehiculoid),('vehiculo',vehiculo),('placa',placa),('anio',anio),('numserie',numserie),\
												('choferid',choferid),('nombre',nombre),('idtipoinspeccion',idtipoinspeccion),('siglascategoriaauto',siglasauto)\
											  ])
					return True
				else:
					self.informe = {'descripcion':'Solicitud no permitida para la asignacion','etapasiglas':str(etapasiglas)}
					return '3'
			else:
				self.informe = "No se encontraron coincidencias para completar la solicitud"
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#2
	def busqueda_cuestionario_inspeccion_asignacion(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			csiglasetapa = {'ASIG':'INSPENTGA','RUTA':'INSPDEVOL'}
			autoid = datos.getElementsByTagName('autoid')[0].firstChild.data
			clienteid = datos.getElementsByTagName('clienteid')[0].firstChild.data
			etapasiglas = datos.getElementsByTagName('etapasiglas')[0].firstChild.data
			valueetapasiglas = csiglasetapa[etapasiglas] #...
			vehiculoid = datos.getElementsByTagName('vehiculoid')[0].firstChild.data
			vehiculoasignacionid = datos.getElementsByTagName('vehiculoasignacionid')[0].firstChild.data
			inspecciontipoid = datos.getElementsByTagName('inspecciontipoid')[0].firstChild.data
			referenciaid = datos.getElementsByTagName('referenciaid')[0].firstChild.data

			tabla = 'inspeccion.inspeccion'
			id_u = ''
			campos = 'idinspeccion'
			where = " WHERE idreferencia=" + str(referenciaid) + " AND idvehiculo=" + str(vehiculoid) + " AND idtipoinspeccion=" + str(inspecciontipoid)
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			idinspeccion = ""
			qry = "select c.idcuestionario,c.cuestionario,c.siglas as siglascuestionario,c.orden as ordencuestionario,ti.idtipoinspeccion,ti.tipoinspeccion,ti.siglas as siglastipoinspeccion,p.idpregunta,p.pregunta,p.siglas as siglaspregunta,tr.siglas as siglastiporespuesta,tr.idtiporespuesta, accp.orden as ordenpregunta,id.respuesta as respuesta, id.idrespuesta as idrespuesta, id.idauxiliar as idauxiliar from inspeccion.pregunta as p inner join inspeccion.tiporespuesta as tr on (tr.idtiporespuesta = p.idtiporespuesta) inner join inspeccion.autoclientecuestionariopregunta as accp on(accp.idpregunta = p.idpregunta) inner join inspeccion.autocliente as ac on(ac.idautocliente=accp.idautocliente) inner join inspeccion.cuestionario as c on(c.idcuestionario = accp.idcuestionario) inner join inspeccion.tipoinspeccion as ti on(ti.idtipoinspeccion = c.idtipoinspeccion) left outer join inspeccion.inspecciondetalle as id on(id.siglaspregunta = p.siglas AND id.idinspeccion=null) where ac.idauto="+str(autoid)+" AND ac.idcliente="+str(clienteid)+" AND ti.siglas='"+str(valueetapasiglas)+"' order by c.orden"
			band = 0
			if(respuesta == True):
				band = 1
				idinspeccion = str(db.rows[0]['idinspeccion'])
				qry = "select c.idcuestionario,c.cuestionario,c.siglas as siglascuestionario,c.orden as ordencuestionario,ti.idtipoinspeccion,ti.tipoinspeccion,ti.siglas as siglastipoinspeccion,p.idpregunta,p.pregunta,p.siglas as siglaspregunta,tr.siglas as siglastiporespuesta,tr.idtiporespuesta, accp.orden as ordenpregunta,id.respuesta as respuesta, id.idrespuesta as idrespuesta, id.idauxiliar as idauxiliar from inspeccion.pregunta as p inner join inspeccion.tiporespuesta as tr on (tr.idtiporespuesta = p.idtiporespuesta) inner join inspeccion.autoclientecuestionariopregunta as accp on(accp.idpregunta = p.idpregunta) inner join inspeccion.autocliente as ac on(ac.idautocliente=accp.idautocliente) inner join inspeccion.cuestionario as c on(c.idcuestionario = accp.idcuestionario) inner join inspeccion.tipoinspeccion as ti on(ti.idtipoinspeccion = c.idtipoinspeccion) left outer join inspeccion.inspecciondetalle as id on(id.siglaspregunta = p.siglas AND id.idinspeccion="+ str(idinspeccion) +") where ac.idauto="+str(autoid)+" AND ac.idcliente="+str(clienteid)+" AND ti.siglas='"+str(valueetapasiglas)+"' order by c.orden"

			db = d.Database(1,1,1)
			respuesta = db.query(qry)

			cuestionariodata = []
			if(respuesta == True):
				numfilas = db.numfilas
				vector = []
				i = 0
				while i < numfilas:
					cuestionarioid = str(db.rows[i]['idcuestionario'])
					cuestionario = unicode(db.rows[i]['cuestionario'],'utf-8')
					cuestionario = unicodedata.normalize('NFKD', cuestionario).encode('ascii','ignore')
					cuestionariosiglas = str(db.rows[i]['siglascuestionario'])
					cuestionarioorden = str(db.rows[i]['ordencuestionario'])
					tipoinspeccionid = str(db.rows[i]['idtipoinspeccion'])
					inspecciontipo = unicode(db.rows[i]['tipoinspeccion'],'utf-8')
					inspecciontipo = unicodedata.normalize('NFKD', inspecciontipo).encode('ascii','ignore')
					tipoinspeccionsiglas = str(db.rows[i]['siglastipoinspeccion'])
					preguntaid = str(db.rows[i]['idpregunta'])
					pregunta = unicode(db.rows[i]['pregunta'],'utf-8')
					pregunta = unicodedata.normalize('NFKD', pregunta).encode('ascii','ignore')
					preguntasiglas = str(db.rows[i]['siglaspregunta'])
					tiporespuestasiglas = str(db.rows[i]['siglastiporespuesta'])
					tiporespuestaid = str(db.rows[i]['idtiporespuesta'])
					if band == 0:
						respuestaid = ""
						respuesta = ""
						auxiliarid = ""
					else:
						respuestaid = str(db.rows[i]['idrespuesta'])
						respuesta = str(db.rows[i]['respuesta'])
						auxiliarid = str(db.rows[i]['idauxiliar'])
					
					preguntaorden = str(db.rows[i]['ordenpregunta'])

					cuestionariodata.append({'cuestionarioid':cuestionarioid,'cuestionario':cuestionario,'cuestionariosiglas':cuestionariosiglas,\
											 'cuestionarioorden':cuestionarioorden,'tipoinspeccionid':tipoinspeccionid,'inspecciontipo':inspecciontipo,\
											 'tipoinspeccionsiglas':tipoinspeccionsiglas,'preguntaid':preguntaid,'pregunta':pregunta,'preguntasiglas':preguntasiglas,\
											 'tiporespuestasiglas':tiporespuestasiglas,'tiporespuestaid':tiporespuestaid,'respuestaid':respuestaid,\
											 'respuesta':respuesta,'auxiliarid':auxiliarid,'preguntaorden':preguntaorden})
					i = i + 1

				self.informe = {'idinspeccion':idinspeccion,'cuestionario':cuestionariodata}
				return True
			else:
				self.informe = "No se cuenta con una inspeccion anterior para completar la solicitud."
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#3
	def guardar_inspeccion_asignacion(self):
		datos = self.imei
		if self.formato == 1:
			
			try:
				asignacionvehiculoid = datos.getElementsByTagName('asignacionvehiculoid')[0].firstChild.data
			except:
				asignacionvehiculoid = 0
			
			try:
				etapasolicitudid = datos.getElementsByTagName('etapasolicitudid')[0].firstChild.data
			except:
				etapasolicitudid = 0
			
			try:
				usuarioid = datos.getElementsByTagName('usuarioid')[0].firstChild.data
			except:
				usuarioid = 0
			
			try:
				vehiculoid = datos.getElementsByTagName('vehiculoid')[0].firstChild.data
			except:
				vehiculoid = 0
			
			try:
				tipovehiculoid = datos.getElementsByTagName('tipovehiculoid')[0].firstChild.data
			except:
				tipovehiculoid = 0
			
			try:
				tipoinspeccionid = datos.getElementsByTagName('tipoinspeccionid')[0].firstChild.data
			except:
				tipoinspeccionid = 0
			
			try:
				fechahora = datos.getElementsByTagName('fechahora')[0].firstChild.data
			except:
				fechahora = ""
			
			try:
				etapasolicitudid = datos.getElementsByTagName('etapasolicitudid')[0].firstChild.data
			except:
				etapasolicitudid = 0
			

			#Verificar que exista la solicitud y/o que no haya sido cambiada de etapa.
			tabla = 'comun.solicitud s,fleetelligent.asignacionvehiculo av'
			id_u = ''
			campos = 's.idsolicitud'
			where = " WHERE av.idasignacionvehiculo=" + str(asignacionvehiculoid) + " AND s.idetapa=" + str(etapasolicitudid) + " AND av.idsolicitud=s.idsolicitud"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				idsolicitud = db.rows[0]['idsolicitud']
				#Verificar si es una actualizacion o una nueva inspeccion
				tabla = 'inspeccion.inspeccion'
				campos = 'idinspeccion'
				where = " WHERE idreferencia=" + str(asignacionvehiculoid) + " AND idvehiculo=" + str(vehiculoid) + " AND idtipoinspeccion=" + str(tipoinspeccionid)
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True):
					#Actualizacion
					idinspeccion = db.rows[0]['idinspeccion']
					for node in datos.getElementsByTagName("inspeccionDetalle"):
						try:
							preguntaid = node.getElementsByTagName('preguntaid')[0].firstChild.data
						except:
							preguntaid = 0
						
						try:
							pregunta = node.getElementsByTagName('pregunta')[0].firstChild.data.encode("utf-8")
							#pregunta = unicode(pregunta,'utf-8')
							#pregunta = unicodedata.normalize('NFKD', pregunta).encode('ascii','ignore')
						except:
							pregunta = ""
						
						try:
							preguntasiglas = node.getElementsByTagName('preguntasiglas')[0].firstChild.data
						except:
							preguntasiglas = ""
						
						try:
							respuestaid = node.getElementsByTagName('respuestaid')[0].firstChild.data
						except:
							respuestaid = 0
						
						try:
							respuesta = node.getElementsByTagName('respuesta')[0].firstChild.data.encode("utf-8")
							#respuesta = unicode(respuesta,'utf-8')
							#respuesta = unicodedata.normalize('NFKD', respuesta).encode('ascii','ignore')
						except:
							respuesta = ""
						
						try:
							fechahora1 = node.getElementsByTagName('fechahora1')[0].firstChild.data
						except:
							fechahora1 = ""
						
						try:
							auxiliarid = node.getElementsByTagName('auxiliarid')[0].firstChild.data
						except:
							auxiliarid = 0
						
						try:
							cuestionarioid = node.getElementsByTagName('cuestionarioid')[0].firstChild.data
						except:
							cuestionarioid = 0

						tabla = 'inspeccion.inspecciondetalle'
						campos = ''
						datau = "idpregunta="+str(preguntaid)+",pregunta='"+str(pregunta)+"',idrespuesta=" + str(respuestaid) + \
								",respuesta='" + str(respuesta) + "',fechamodificacion=NOW(),fechahora='"+str(fechahora1)+"',idauxiliar="+str(auxiliarid)+\
								",idcuestionario=" + str(cuestionarioid)
						where = " WHERE siglaspregunta='" + str(preguntasiglas) + "' AND idinspeccion=" + str(idinspeccion)
						db = d.Database(tabla,id_u,campos)
						respuesta = db.modificar(datau,where)
					self.informe = {'idinspeccion':idinspeccion}
					return True 	#Actualizado
				else:
					#Nueva inspeccion
					tabla = 'inspeccion.inspeccion'
					campos = 'idvehiculo,idtipoinspeccion,activo,fechacreacion,fechamodificacion,fechahora,idreferencia,idusuario'
					values = str(vehiculoid) + "," + str(tipoinspeccionid) + ",TRUE,NOW(),NOW(),'"+str(fechahora)+"',"+str(asignacionvehiculoid)+","+str(usuarioid)
					db = d.Database(tabla,id_u,campos)
					returning = " RETURNING idinspeccion"
					respuesta = db.add(values,returning)
					if(respuesta == True):
						idinspeccion = db.row[0]['idinspeccion']
						for node in datos.getElementsByTagName("inspeccionDetalle"):
							try:
								preguntaid = node.getElementsByTagName('preguntaid')[0].firstChild.data
							except:
								preguntaid = 0
							
							try:
								pregunta = node.getElementsByTagName('pregunta')[0].firstChild.data.encode("utf-8")
								#pregunta = unicode(pregunta,'utf-8')
								#pregunta = unicodedata.normalize('NFKD', pregunta).encode('ascii','ignore')
							except:
								pregunta = ""
							
							try:
								preguntasiglas = node.getElementsByTagName('preguntasiglas')[0].firstChild.data
							except:
								preguntasiglas = ""
							
							try:
								respuestaid = node.getElementsByTagName('respuestaid')[0].firstChild.data
							except:
								respuestaid = 0
							
							try:
								respuesta = node.getElementsByTagName('respuesta')[0].firstChild.data.encode("utf-8")
								#respuesta = unicode(respuesta,'utf-8')
								#respuesta = unicodedata.normalize('NFKD', respuesta).encode('ascii','ignore')
							except:
								respuesta = ""
							
							try:
								fechahora1 = node.getElementsByTagName('fechahora1')[0].firstChild.data
							except:
								fechahora1 = ""
							
							try:
								auxiliarid = node.getElementsByTagName('auxiliarid')[0].firstChild.data
							except:
								auxiliarid = 0
							
							try:
								cuestionarioid = node.getElementsByTagName('cuestionarioid')[0].firstChild.data
							except:
								cuestionarioid = 0
							
							#Se crea el detalle de la inspeccion
							tabla = 'inspeccion.inspecciondetalle'
							campos = 'idinspeccion,idpregunta,pregunta,siglaspregunta,idrespuesta,respuesta,activo,fechacreacion,fechamodificacion,\
									  fechahora,idauxiliar,idcuestionario'
							values = str(idinspeccion) + "," + str(preguntaid) + ",'" + str(pregunta) + "','" + str(preguntasiglas) +"'," +\
									 str(respuestaid) + ",'" + str(respuesta) +"',TRUE,NOW(),NOW(),'"+str(fechahora1)+"',"+str(auxiliarid)+","+\
									 str(cuestionarioid)
							db = d.Database(tabla,id_u,campos)
							returning = " RETURNING idinspecciondetalle"
							respuesta = db.add(values,returning)
						self.informe = {'idinspeccion':idinspeccion}
						return True	 #Almacenado nuevo
					else:
						self.informe = "Hubo un problema al realizar la solicitud. Intente de nuevo"
						return '2'
			else:
				self.informe = "No existe la solicitud o fue cambiada de etapa"
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#4
	def busqueda_cuestionario_inspeccion_no_asignacion(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			clienteid = datos.getElementsByTagName('clienteid')[0].firstChild.data
			vehiculoid = datos.getElementsByTagName('vehiculoid')[0].firstChild.data
			siglas = datos.getElementsByTagName('siglas')[0].firstChild.data

			tabla = 'fleetelligent.vehiculo'
			id_u = ''
			campos = 'idauto'
			where = " WHERE idvehiculo=" + str(vehiculoid)
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				idauto=db.rows[0]['idauto']
				tabla = 'inspeccion.autoclientecuestionariopregunta accp,inspeccion.autocliente ac,inspeccion.pregunta p,inspeccion.tiporespuesta tr,\
						 inspeccion.cuestionario c,inspeccion.tipoinspeccion ti'
				campos = 'c.idcuestionario,c.cuestionario,c.siglas as siglascuestionario,c.orden as ordencuestionario,ti.idtipoinspeccion,ti.tipoinspeccion,\
						  ti.siglas as siglastipoinspeccion,p.idpregunta,p.pregunta,p.siglas as siglaspregunta,tr.siglas as siglastiporespuesta,tr.idtiporespuesta,\
						  accp.orden as ordenpregunta'
				where = " WHERE ac.idautocliente = accp.idautocliente AND p.idpregunta=accp.idpregunta AND \
						  tr.idtiporespuesta = p.idtiporespuesta AND c.idcuestionario = accp.idcuestionario AND ti.idtipoinspeccion=c.idtipoinspeccion  \
						  AND ac.idauto=" + str(idauto) + " AND ac.idcliente=" + str(clienteid) +\
						  " AND ti.siglas='" + str(siglas) + "' ORDER BY c.orden"
				
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				cuestionariodata = []
				if(respuesta == True):
					numfilas = db.numfilas
					vector = []
					i = 0
					while i < numfilas:
						cuestionarioid = str(db.rows[i]['idcuestionario'])
						cuestionario = str(db.rows[i]['cuestionario'])
						cuestionariosiglas = str(db.rows[i]['siglascuestionario'])
						cuestionarioorden = str(db.rows[i]['ordencuestionario'])
						tipoinspeccionid = str(db.rows[i]['idtipoinspeccion'])
						inspecciontipo = str(db.rows[i]['tipoinspeccion'])
						tipoinspeccionsiglas = str(db.rows[i]['siglastipoinspeccion'])
						preguntaid = str(db.rows[i]['idpregunta'])
						pregunta = str(db.rows[i]['pregunta'])
						preguntasiglas = str(db.rows[i]['siglaspregunta'])
						tiporespuestasiglas = str(db.rows[i]['siglastiporespuesta'])
						tiporespuestaid = str(db.rows[i]['idtiporespuesta'])
						preguntaorden = str(db.rows[i]['siglastiporespuesta'])
							
						cuestionariodata.append({'cuestionarioid':cuestionarioid,'cuestionario':cuestionario,'cuestionariosiglas':cuestionariosiglas,\
												 'cuestionarioorden':cuestionarioorden,'tipoinspeccionid':tipoinspeccionid,'inspecciontipo':inspecciontipo,\
												 'tipoinspeccionsiglas':tipoinspeccionsiglas,'preguntaid':preguntaid,'pregunta':pregunta,'preguntasiglas':preguntasiglas,\
												 'tiporespuestasiglas':tiporespuestasiglas,'tiporespuestaid':tiporespuestaid,\
												 'preguntaorden':preguntaorden})
						i = i + 1

					self.informe = cuestionariodata
					return True
				
				else:
					self.informe = "No se encontraron coincidencias para completar la solicitud."
					return '2'
			else:
				self.informe = "No se encontraro coincidencias con el idvehiculo proporcionado"
				return '2'
		elif self.formato == 2:
				msg = 'json'
				return True
		else:
			return False
	
	#5
	def guardar_inspeccion_no_asignacion(self):
		datos = self.imei
		if self.formato == 1:
			
			try:
				asignacionvehiculoid = int(datos.getElementsByTagName('asignacionvehiculoid')[0].firstChild.data)
			except:
				asignacionvehiculoid = 0
			
			try:
				etapasolicitudid = int(datos.getElementsByTagName('etapasolicitudid')[0].firstChild.data)
			except:
				etapasolicitudid = 0
			
			try:
				usuarioid = int(datos.getElementsByTagName('usuarioid')[0].firstChild.data)
			except:
				usuarioid = 0
			
			try:
				vehiculoid = int(datos.getElementsByTagName('vehiculoid')[0].firstChild.data)
			except:
				vehiculoid = 0
			
			try:
				tipovehiculoid = int(datos.getElementsByTagName('tipovehiculoid')[0].firstChild.data)
			except:
				tipovehiculoid = 0
			
			try:
				tipoinspeccionid = int(datos.getElementsByTagName('tipoinspeccionid')[0].firstChild.data)
			except:
				tipoinspeccionid = 0
			
			try:
				fechahora = datos.getElementsByTagName('fechahora')[0].firstChild.data
			except:
				fechahora = ""
			
			try:
				etapasolicitudid = int(datos.getElementsByTagName('etapasolicitudid')[0].firstChild.data)
			except:
				etapasolicitudid = 0

			#Nueva inspeccion
			id_u = ''
			tabla = 'inspeccion.inspeccion'
			campos = 'idvehiculo,idtipoinspeccion,activo,fechacreacion,fechamodificacion,fechahora,idreferencia,idusuario'
			values = str(vehiculoid) + "," + str(tipoinspeccionid) + ",TRUE,NOW(),NOW(),'"+str(fechahora)+"',"+str(asignacionvehiculoid)+","+str(usuarioid)
			db = d.Database(tabla,id_u,campos)
			returning = " RETURNING idinspeccion"
			respuesta = db.add(values,returning)
			if(respuesta == True):
				idinspeccion = db.row[0]['idinspeccion']
				for node in datos.getElementsByTagName("inspeccionDetalle"):
					try:
						preguntaid = int(node.getElementsByTagName('preguntaid')[0].firstChild.data)
					except:
						preguntaid = 0
					
					try:
						pregunta = node.getElementsByTagName('pregunta')[0].firstChild.data.encode("utf-8")
						#pregunta = unicode(pregunta,'utf-8')
						#pregunta = unicodedata.normalize('NFKD', pregunta).encode('ascii','ignore')
					except:
						pregunta = ""
					try:
						preguntasiglas = node.getElementsByTagName('preguntasiglas')[0].firstChild.data.encode("utf-8")
					except:
						preguntasiglas = ""
					
					try:
						respuestaid = int(node.getElementsByTagName('respuestaid')[0].firstChild.data)
					except:
						respuestaid = 0
					
					try:
						respuesta = node.getElementsByTagName('respuesta')[0].firstChild.data.encode("utf-8")
						#respuesta = unicode(respuesta,'utf-8')
						#respuesta = unicodedata.normalize('NFKD', respuesta).encode('ascii','ignore')
					except:
						respuesta = ""
					
					try:
						fechahora1 = node.getElementsByTagName('fechahora1')[0].firstChild.data
					except:
						fechahora1 = ""
					
					try:
						auxiliarid = int(node.getElementsByTagName('auxiliarid')[0].firstChild.data)
					except:
						auxiliarid = 0
					
					try:
						cuestionarioid = int(node.getElementsByTagName('cuestionarioid')[0].firstChild.data)
					except:
						cuestionarioid = 0
					
					
					#Se crea el detalle de la inspeccion
					tabla = 'inspeccion.inspecciondetalle'
					campos = 'idinspeccion,idpregunta,pregunta,siglaspregunta,idrespuesta,respuesta,activo,fechacreacion,fechamodificacion,\
							  fechahora,idauxiliar,idcuestionario'
					values = str(idinspeccion) + "," + str(preguntaid) + ",'" + str(pregunta) + "','" + str(preguntasiglas) +"'," +\
							 str(respuestaid) + ",'" + str(respuesta) +"',TRUE,NOW(),NOW(),'"+str(fechahora1)+"',"+str(auxiliarid)+","+\
							 str(cuestionarioid)
					db = d.Database(tabla,id_u,campos)
					returning = " RETURNING idinspecciondetalle"
					respuesta = db.add(values,returning)
				#self.informe = "Datos almacenados correctamente"
				self.informe = {'idinspeccion':idinspeccion}
				return True	 #Almacenado nuevo
			else:
				self.informe = "Hubo un problema al realizar la solicitud. Intente de nuevo"
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False
	
	#6
	def aceptar_inspeccion_asignacion(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			asignacionvehiculoid = datos.getElementsByTagName('asignacionvehiculoid')[0].firstChild.data
			usuarioid = datos.getElementsByTagName('usuarioid')[0].firstChild.data
			etapasolicitudid = datos.getElementsByTagName('etapasolicitudid')[0].firstChild.data

			#Buscar la solicitud correspondiente.
			id_u = ''
			tabla = 'comun.solicitud s,comun.etapa e,fleetelligent.asignacionvehiculo av'
			campos = 's.idsolicitud as idsolicitud,e.siglas as siglasetapa,s.idproceso as idproceso,av.idvehiculo as idvehiculo'
			where = " WHERE av.idasignacionvehiculo=" + str(asignacionvehiculoid) + " AND s.idetapa="+ str(etapasolicitudid) + \
					" AND av.idsolicitud=s.idsolicitud AND e.idetapa=s.idetapa"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				idsolicitud = str(db.rows[0]['idsolicitud'])
				siglasetapa = str(db.rows[0]['siglasetapa']) #ASIG O RUTA
				idproceso = str(db.rows[0]['idproceso'])
				idvehiculo = str(db.rows[0]['idvehiculo'])
				#Busqueda de tipo inspeccion con la sigla
				csiglasetapa = {'ASIG':'INSPENTGA','RUTA':'INSPDEVOL'}
				valueetapasiglas = csiglasetapa[siglasetapa] #INSPENTGA o INSPDEVOL

				#select idtipoinspeccion from inspeccion.tipoinspeccion where siglas like 'valueetapasiglas'
				cidtipoinspeccion = {'INSPEXP':1,'INSPENTGA':2,'INSPDEVOL':3,'INSPDRIA':4}
				idtipoinspeccion = cidtipoinspeccion[valueetapasiglas]
				tabla = 'inspeccion.inspeccion'
				campos = 'idinspeccion'
				where = " WHERE idvehiculo=" + str(idvehiculo) + " AND idreferencia=" + str(asignacionvehiculoid) + " AND idtipoinspeccion="+str(idtipoinspeccion)
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				idinspeccion = str(db.rows[0]['idinspeccion']) #
				#Buscar la etapa siguiente
				cetapasiguiente = {'INSPENTGA':'RUTA','INSPDEVOL':'FIN'}
				etapaSiguienteSigla = cetapasiguiente[valueetapasiglas] #RUTA O FIN
				
				#se obtiene el id de la etapa siguiente
				tabla = 'comun.flujo f,comun.etapa e'
				campos = 'f.idetapasiguiente'
				where = " WHERE e.idetapa = f.idetapasiguiente AND f.idproceso=" + str(idproceso) + " AND f.idetapa=" + str(etapasolicitudid) + \
						" AND e.siglas='"+str(etapaSiguienteSigla)+"'"
				db = d.Database(tabla,id_u,campos)
				respuesta = db.get(where)
				if(respuesta == True):
					idetapasiguiente = str(db.rows[0]['idetapasiguiente'])
					#Si se encuentra se actualiza la etapa de la solicitud
					tabla = 'comun.solicitud'
					campos = ''
					datau = "idetapa="+str(idetapasiguiente)
					where = " WHERE idsolicitud=" + str(idsolicitud)
					db = d.Database(tabla,id_u,campos)
					respuesta = db.modificar(datau,where)
					#Se actualiza la fecha de recepción y/o salida de la tabla asignacionvehiculo.
					cfechaupdate = {'INSPENTGA':'fechasalida','INSPDEVOL':'fecharecepcion'}
					fechaupdate = cfechaupdate[valueetapasiglas] #fechasalida O fecharecepcion
					tabla = 'fleetelligent.asignacionvehiculo'
					campos = ''
					datau = str(fechaupdate)+"=NOW()"
					where = " WHERE idasignacionvehiculo=" + str(asignacionvehiculoid)
					db = d.Database(tabla,id_u,campos)
					respuesta = db.modificar(datau,where)
					#Crear el seguimiento
					tabla = 'comun.solicitudseguimiento'
					campos = 'idsolicitud,idusuario,idetapa,fecha'
					values = str(idsolicitud) + "," + str(usuarioid) + "," + str(idetapasiguiente) + ",NOW()"
					db = d.Database(tabla,id_u,campos)
					returning = " RETURNING idsolicitudseguimiento"
					respuesta = db.add(values,returning)
					idsolicitudseguimiento = db.row[0]['idsolicitudseguimiento']
					if(respuesta == True):
						self.informe = "Solicitud atendida satisfactoriamente"
						return True
				else:
					self.informe = "No se encontraron coincidencias para completar la solicitud"
					return '2'
			else:
				self.informe = "No se encontraron coincidencias para completar la solicitud"
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False
	

#busqueda asignacion por folio y vehiculo
	def busqueda_asignacion_folio_vehiculo(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			siglasetapa = {'ETAPARUTA':'RUTA','ETAPAINSPENTRADA':'RUTA',}
			folio = datos.getElementsByTagName('folio')[0].firstChild.data
			idvehiculo = datos.getElementsByTagName('idvehiculo')[0].firstChild.data
			id_u = ''
			tabla = 'comun.solicitud s,comun.etapa e,fleetelligent.asignacionvehiculo av'
			campos = 's.idsolicitud,s.folio,e.nombre'
			where = " WHERE s.folio!=" + str(folio) + " AND av.idsolicitud = s.idsolicitud AND e.idetapa=s.idetapa AND e.siglas='RUTA' AND av.idvehiculo="+str(idvehiculo)
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				idsolicitud = str(db.rows[0]['idsolicitud'])
				foliosolicitud = str(db.rows[0]['folio'])
				nombreetapa = str(db.rows[0]['nombre'])
				self.informe = {'idsolicitud':idsolicitud,'foliosolicitud':foliosolicitud,'nombreetapa':nombreetapa}
				return True
			else:
				self.informe = "No se encontraron coincidencias para completar la solicitud"
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	
	#busqueda asignacion pendiente por fecha
	def busqueda_asignacion_pendiente_fecha(self):
		datos = self.imei
		campos = []
		if self.formato == 1:
			siglasetapa = {'ETAPAASIGVEHICULO':'ASIG','ETAPARUTA':'RUTA',}
			fecha = datos.getElementsByTagName('fecha')[0].firstChild.data
			id_u = ''
			tabla = 'comun.solicitud s,comun.etapa e,fleetelligent.asignacionvehiculo av,fleetelligent.vehiculo v'
			campos = 's.idsolicitud,s.folio, av.fechasalida,av.fecharecepcion,v.nombre,e.nombre as etapa '
			where = " WHERE (date(av.fechasalida)='" + str(fecha) + "' OR date(av.fecharecepcion)='" + str(fecha) +"') AND s.idetapa in (3,5) AND e.idetapa=s.idetapa AND av.idsolicitud=s.idsolicitud AND v.idvehiculo=av.idvehiculo ORDER BY av.fechasalida"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				
				numfilas = db.numfilas
				vector = []
				i = 0
				while i < numfilas:
					idsolicitud = str(db.rows[i]['idsolicitud'])
					foliosolicitud = str(db.rows[i]['folio'])
					fechasalida = str(db.rows[i]['fechasalida'])
					fecharecepcion = str(db.rows[i]['fecharecepcion'])
					nombrevehiculo = str(db.rows[i]['nombre'])
					nombreetapa = str(db.rows[i]['etapa'])
					vector.append({'idsolicitud':idsolicitud,'foliosolicitud':foliosolicitud,'fechasalida':fechasalida,'fecharecepcion':fecharecepcion,'nombrevehiculo':nombrevehiculo,'nombreetapa':nombreetapa})
					i = i + 1
				self.informe = vector
				return True
			else:
				self.informe = "No se encontraron coincidencias para completar la solicitud:" + str(fecha)
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False


	def choferes_accion(self,operacion):
		if self.formato == 1:
			try:
				if (operacion == '1'):
					resultado = self.busqueda_lista_choferes_vehiculo()
				return resultado
			except:
				self.informe = "No se pudo completar la solicitud."
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#1
	def busqueda_lista_choferes_vehiculo(self):	
		try:
			contenido = self.imei
			vehiculoid = contenido.getElementsByTagName('vehiculoid')[0].firstChild.data
			
			#Se obtienen los campos  choferfijo y el idauto de la tabla vehiculo donde el idvehiculo sea igual al valor de entrada.
			tabla = 'fleetelligent.vehiculo'
			id_u = ''
			campos = 'choferfijo,idauto'
			where = " WHERE idvehiculo=" + str(vehiculoid)
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				choferfijo = db.rows[0]['choferfijo']
				idauto = db.rows[0]['idauto']
				#Si el campo choferfijo es true se buscan los choferes que están asignados a ese vehiculo
				if choferfijo=='t':
					###...
					choferes = "N/A"
					tabla = 'fleetelligent.chofervehiculo cv,fleetelligent.chofer c,comun.persona p'
					campos = 'p.nombre,p.apellidopaterno,p.apellidomaterno,c.idchofer'
					where = " WHERE cv.idvehiculo=" + str(vehiculoid) + " AND c.idpersona=p.idpersona AND cv.idchofer = c.idchofer ORDER BY c.idchofer"
					db = d.Database(tabla,id_u,campos)
					respuesta = db.get(where)
					if(respuesta == True):    # Si el vehiculo tiene choferes disponibles
						numfilas = db.numfilas
						vector = []
						i = 0
						while i < numfilas:
							idchofer = db.rows[i]['idchofer']
							n = ""
							ap = ""
							am = ""
							if(db.rows[i]['nombre']!=None):
								n = unicode(db.rows[i]['nombre'],'utf-8')
								n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
							if(db.rows[i]['apellidopaterno']!=None):
								ap = unicode(db.rows[i]['apellidopaterno'],'utf-8')
								ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
							if(db.rows[i]['apellidomaterno']!=None):
								am = unicode(db.rows[i]['apellidomaterno'],'utf-8')
								am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')
							nombre = n + " " + ap + " " + am
							vector.append({'nombre':nombre,'idchofer':idchofer})
							i = i + 1
						choferes = vector
						self.informe = choferes
						return True
					else:
						self.informe = "Sin choferes disponibles!"
						return '2'
					###...
				#Si el campo choferfijo es falso se buscan los choferes con el idauto obtenido de la primera consulta
				else:
					choferes = "N/A"
					tabla = 'fleetelligent.chofer c,comun.persona p'
					campos = 'p.nombre,p.apellidopaterno,p.apellidomaterno,c.idchofer'
					where = " WHERE c.idpersona=p.idpersona AND p.activo=TRUE AND c.idtipolicencia in \
							  (select idtipolicencia from comun.autotipolicencia where idauto= "+ str(idauto) + ") AND c.idchofer not in \
							  (select idchofer from fleetelligent.chofervehiculo) AND c.activo=TRUE ORDER BY c.idchofer"
					db = d.Database(tabla,id_u,campos)
					respuesta = db.get(where)
					if(respuesta == True):	    # Si el vehiculo tiene choferes disponibles
						numfilas = db.numfilas
						vector = []
						i = 0
						while i < numfilas:
							idchofer = db.rows[i]['idchofer']
							n = ""
							ap = ""
							am = ""
							if(db.rows[i]['nombre']!=None):
								n = unicode(db.rows[i]['nombre'],'utf-8')
								n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
							if(db.rows[i]['apellidopaterno']!=None):
								ap = unicode(db.rows[i]['apellidopaterno'],'utf-8')
								ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
							if(db.rows[i]['apellidomaterno']!=None):
								am = unicode(db.rows[i]['apellidomaterno'],'utf-8')
								am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')
							nombre = n + " " + ap + " " + am
							vector.append({'nombre':nombre,'idchofer':idchofer})
							i = i + 1
						choferes = vector
						self.informe = choferes
						return True
					else:
						self.informe = "Sin choferes disponibles!"
						return '2'
					
			else:
				self.informe = "El vehiculo no existe!"
				return '2'
		except:
			self.informe = "Datos incorrectos!"
			return '2'

	
	def cuestionario_accion(self,operacion):
		if self.formato == 1:
			try:
				if (operacion == 'respuesta'):
					resultado = self.busqueda_respuesta()
				return resultado
			except:
				self.informe = "No se pudo completar la solicitud."
				return '2'
		elif self.formato == 2:
			msg = 'json'
			return True
		else:
			return False

	#respuesta
	def busqueda_respuesta(self):	
		try:
			#select idrespuesta,respuesta,idtiporespuesta,orden from inspeccion.respuesta order by idtiporespuesta, orden
			tabla = 'inspeccion.respuesta'
			id_u = ''
			campos = 'idrespuesta,respuesta,idtiporespuesta,orden'
			where = " ORDER BY idtiporespuesta, orden"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			if(respuesta == True):
				numfilas = db.numfilas
				vector = []
				i = 0
				while i < numfilas:
					idrespuesta = db.rows[i]['idrespuesta']
					respuesta = db.rows[i]['respuesta']
					idtiporespuesta = db.rows[i]['idtiporespuesta']
					orden = db.rows[i]['orden']
					vector.append({'idrespuesta':idrespuesta,'respuesta':respuesta,'idtiporespuesta':idtiporespuesta,'orden':orden})
					i = i + 1
				self.informe = vector
				return True
				
			else:
				self.informe = "No se encontraron coincidencias para completar la solicitud"
				return '2'
		except:
			self.informe = "Datos incorrectos!"
			return '2'



