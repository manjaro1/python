#!/usr/bin/env python
# -*- coding: UTF-8 -*- 
import os, random, string
import codecs
import unicodedata
from ws.model import database as d
from ws.libraries import security as s


class Usuario():
	def __init__(self, datos, tipo):
        	self.contenido = datos
        	self.formato = tipo
	        self.id = 0
        	self.nombre = None        
	        self.informe = None
		
	def datos_accion(self,consulta):
		if (consulta == '1'):
			resultado = self.consultar_datos()
		elif (consulta == '2'):
			resultado = self.consultar_usuario()
		return resultado
		
	
	def registro(self):
		exito = False		
		return exito

	def consultar_datos(self):				
		tabla = 'usuario u,tipo_usuario t'
		id_u = ''
		campos = 'u.id_usuario,u.nombre,u.apellido_paterno,u.apellido_materno,t.tipo_usuario'		
		where = " WHERE u.id_tipo_usuario=t.id_tipo_usuario ORDER BY u.id_usuario ASC"		
		db = d.Database(tabla,id_u,campos)
		respuesta = db.get(where)
		if respuesta == True:
			numfilas = db.numfilas
			vector = []
			i = 0
			while i < numfilas:				
				id_ = db.rows[i]['id_usuario']
				tipo_usuario = db.rows[i]['tipo_usuario']
				
				nombre = unicode(db.rows[i]['nombre'],'utf-8')
				nombre = unicodedata.normalize('NFKD', nombre).encode('ascii','ignore')				
				paterno = unicode(db.rows[i]['apellido_paterno'],'utf-8')
				paterno = unicodedata.normalize('NFKD', paterno).encode('ascii','ignore')
				materno = unicode(db.rows[i]['apellido_materno'],'utf-8')
				materno = unicodedata.normalize('NFKD', materno).encode('ascii','ignore')
				nombre = nombre + " " + paterno + " " + materno
				
				tabla = 'usuario u,vehiculo v, inspeccion i'
				id_u = ''
				campos = 'v.placa'		
				where = " WHERE i.id_usuario='" + str(id_) + "' AND i.id_vehiculo=v.id_vehiculo"
				db1 = d.Database(tabla,id_u,campos)
				respuesta = db1.get(where)
				placa = 'No asignado'
				if respuesta == True:
					placa = db1.rows[0]['placa']
				vector.append({'Id':id_,'Nombre':nombre,'tipo_usuario':tipo_usuario,'placa_asignado':placa})						
				i = i + 1
			self.valores = vector			
			return True
		else:
			return False
			
	def consultar_usuario(self):				
		try:
			usuario = self.contenido.getElementsByTagName('usuario')[0].firstChild.data
			contrasenia = self.contenido.getElementsByTagName('contrasenia')[0].firstChild.data
		
			#pass_enc = s.aes_encrypt(str(contrasenia),'1233ffnt5801igen') #QUITAR
			#pwd = s.aes_decrypt(str(pass_enc),'1233ffnt5801igen')
			pwd = contrasenia

			tabla = 'usuario.usuario u,fleetelligent.inspector i,comun.persona p'
			id_u = ''
			campos = 'u.contrasenia,u.idusuario,p.nombre,p.apellidopaterno,p.apellidomaterno,p.idcliente'		
			where = " WHERE u.nombreusuario='" + str(usuario) + "' AND u.idpersona=i.idpersona AND u.idpersona=p.idpersona AND u.activo=TRUE AND i.activo=TRUE"
			db = d.Database(tabla,id_u,campos)
			respuesta = db.get(where)
			
			clave = db.rows[0]['contrasenia']
			pwd_hash = s.to_hash(pwd,clave)
			if(clave == pwd_hash):   	#Usuario registrado
				n = '-'
				ap = '-'
				am = '-'
				if(db.rows[0]['nombre']!=None):
					n = unicode(db.rows[0]['nombre'],'utf-8')
					n = unicodedata.normalize('NFKD', n).encode('ascii','ignore')
				if(db.rows[0]['apellidopaterno']!=None):
					ap = unicode(db.rows[0]['apellidopaterno'],'utf-8')
					ap = unicodedata.normalize('NFKD', ap).encode('ascii','ignore')
				if(db.rows[0]['apellidomaterno']!=None):
					am = unicode(db.rows[0]['apellidomaterno'],'utf-8')
					am = unicodedata.normalize('NFKD', am).encode('ascii','ignore')

				nombre = n + ' ' + ap + ' ' + am
				self.informe = {'Usuario_ID':db.rows[0]['idusuario'],'Nombre':nombre,'Cliente_ID':db.rows[0]['idcliente']}
				return True
			else:
				self.informe = "El password del usuario es incorrecto!"
				return '1' #Contrasenia incorrecta			
		except:
			self.informe = "El usuario no existe o se encuentra inactivo!"
			return '2' #Usuario no existe o esta inactivo
			
		
	def actualizar_datos(self):
		exito = False
		return exito		

