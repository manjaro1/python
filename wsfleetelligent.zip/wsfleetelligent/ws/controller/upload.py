#import unicodedata
#import os, random, string
#import sys
import time
import datetime
from ws.model import database as d

class Upload:

	def __init__(self,datos):
		self.xml	= None
		self.datos	= datos

	def existe_img(self):	#Buscar si existe imagen con el idinspeccion y tipoimagen
		idinspeccion = self.datos['idinspeccion']
		idtipoimagen = self.datos['idtipoimagen']

		tabla = 'inspeccion.inspeccionimagen'
		id_u = ''
		campos = 'idinspeccionimagen'
		where = " WHERE idinspeccion=" + str(idinspeccion) + " AND idtipoimagen=" + str(idtipoimagen) + " AND activo=TRUE"
		db = d.Database(tabla,id_u,campos)
		respuesta = db.get(where)
		if(respuesta == True):	#Si existe imagen
			idinspeccionimagen = db.rows[0]['idinspeccionimagen']
			return idinspeccionimagen
		else:					#Si no existe imagen
			return False

	def nueva_ruta_img(self):	#Crear el registron con los datos de una nueva imagen
		ruta = self.datos['ruta']
		idinspeccion = self.datos['idinspeccion']
		idtipoimagen = self.datos['idtipoimagen']

		#Se crea resgistro de la imagen
		id_u = ''
		tabla = 'inspeccion.inspeccionimagen'
		campos = 'rutaimagen,idinspeccion,idtipoimagen,activo,fechacreacion,fechamodificacion'
		values = "'" + str(ruta) + "'," + str(idinspeccion) + "," + str(idtipoimagen) + ",TRUE,NOW(),NOW()"
		db = d.Database(tabla,id_u,campos)
		returning = " RETURNING idinspeccionimagen"
		respuesta = db.add(values,returning)
		
		return respuesta


	def update_ruta_img(self,respuesta):
		ruta = self.datos['ruta']
		qry = "UPDATE inspeccion.inspeccionimagen SET rutaimagen='"+str(ruta)+"',fechamodificacion=NOW() WHERE idinspeccionimagen="+str(respuesta)
		db = d.Database(1,1,1)
		respuesta = db.query(qry)
		return respuesta


	def get_ruta_img(self,respuesta):	#Devolver la ruta de una imagen
		idinspeccion = self.datos['idinspeccion']
		idtipoimagen = self.datos['idtipoimagen']

		tabla = 'inspeccion.inspeccionimagen'
		id_u = ''
		campos = 'rutaimagen'
		where = " WHERE idinspeccion=" + str(idinspeccion) + " AND idtipoimagen=" + str(idtipoimagen) + " AND activo=TRUE"
		db = d.Database(tabla,id_u,campos)
		respuesta = db.get(where)
		if(respuesta == True):	#Si existe imagen
			rutaimagen = db.rows[0]['rutaimagen']
			return rutaimagen
		else:					#Si no existe imagen
			return False


