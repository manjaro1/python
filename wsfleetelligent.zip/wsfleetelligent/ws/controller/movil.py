# -*- coding: utf-8 -*-
import os, random, string
import time
import datetime
import unicodedata
import re
from numpy import *
from ordereddict import OrderedDict
from math import fabs
from ws.model import database as d
from ws.libraries import security as s

class Movil:

	def __init__(self,tipo):
		self.tipo = tipo
		
		
	def login(self):
		return 'test'	