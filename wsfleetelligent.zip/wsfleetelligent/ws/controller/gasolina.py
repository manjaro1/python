#import unicodedata
#import os, random, string
#import sys
import time
import datetime
from numpy import *
from math import fabs
from ws.model import database as d

class Gasolina:

	def __init__(self,imei):
		self.xml	= None
		self.imei	= imei

	def gasolina_interpolacion(self, datos):
		xy = 1
		if(xy == 1):
		#try:
			
			
			fecha_i = str(datos.getElementsByTagName('fecha_i')[0].firstChild.data)
			fecha_f = str(datos.getElementsByTagName('fecha_f')[0].firstChild.data)
			self.anio	= str(datos.getElementsByTagName('anio')[0].firstChild.data)
			#self.anio=2007
			#fecha_i=1379394000
			#fecha_f=1379653199
			self.idauto = str(datos.getElementsByTagName('autoid')[0].firstChild.data)
			

			#Busqueda de primer vector AIN2
			where = " WHERE (timestamp BETWEEN " + str(fecha_i) + " AND " + str(fecha_f) + ") AND imei = " + str(self.imei) + " ORDER BY timestamp ASC"
			db = d.Database("public.rupbasic_data"," ","\"DIN4\",\"AIN2\",timestamp")
			#return where
			respuesta = db.get(where)
			
			if(respuesta == True):
				numfilas	= db.numfilas
				DIN4		= -1	#-1 = random, when 0 = off and 1 = on
				vm			= array([])
				fechas		= array([])
				
				for i in arange(numfilas):
					if(db.rows[i]['DIN4'] is None):
						if(DIN4 == -1):
							
							#Buscar si estaba encendido o apagado
							where2 = " WHERE imei = " + str(self.imei) + " AND \"DIN4\" IS NOT NULL AND timestamp<="+str(db.rows[i]['timestamp']) +" ORDER BY timestamp DESC LIMIT 1"
							db2 = d.Database("public.rupbasic_data"," ","\"DIN4\"")
							respuesta2 = db2.get(where2)
							DIN4 = db2.rows[0]['DIN4']
					else:
						DIN4 = db.rows[i]['DIN4']
					
					if(DIN4 == 1):
						AIN2	= db.rows[i]['AIN2']
						if (AIN2 > 150):
							fecha	= db.rows[i]['timestamp']
							st		= datetime.datetime.fromtimestamp(fecha).strftime('%Y-%m-%d %H:%M:%S')
							fechas	= append(fechas,st)
							vm		= append(vm, AIN2)
					
			else:
				self.informe = 'Sin resultados vm'
				return '1'
			
			#Busqueda de voltaje y litros
			voltaje	= array ([])
			litro	= array ([])
			
			#sql = "SELECT litros, voltaje FROM comun.calibracioncombustibledetalle"
			#sql += " WHERE idcalibracioncombustible in"
			#sql += " (SELECT idcalibracioncombustible FROM comun.autocalibracioncombustible"
			#sql += " WHERE idauto = "+ str(self.idauto) + " AND anio = " + str(self.anio) + ' '
			#sql += "AND activo = TRUE) ORDER BY voltaje ASC"
			sql  = "SELECT litros, voltaje FROM comun.calibracioncombustible"
			sql += " WHERE idcalibracion in"
			sql += " (SELECT idcalibracion FROM comun.autocalibracioncombustible"
			sql += " WHERE idauto = "+ str(self.idauto) + " AND anio = " + str(self.anio) + ' '
			sql += "AND activo = TRUE) ORDER BY voltaje ASC"
			db1 = d.Database("","","")
			respuesta1 = db1.query(sql)
			
			if(respuesta1 == True):
				numfilas1 = db1.numfilas
				
				for k in arange(numfilas1):
					voltaje = append(voltaje, float(db1.rows[k]['voltaje']))
					litro 	= append(litro, db1.rows[k]['litros'])
					
			else:
				self.informe = 'Sin resultados voltaje y litros'
				return '1'
						
			litros = array([])
			longitud = len(vm)
			
			for j in arange(longitud):
				li		= interp(float(vm[j])*0.001,voltaje,litro)
				litros	= append(litros,li)
				
			#convirtiendo numpy.array a python list
			litros = litros.tolist()
			fechas = fechas.tolist()
						
			resultado = self.min_max(litros,fechas)
			#return resultado
			self.informe = resultado
			return True
				
		#except:
			#self.informe = "Datos incorrectos"
			#return '2'	
	
	def apply(self,func,nArray):
		r = array(list(map(func, nArray)))
		return r
	
	
	def min_max(self,p,f):
		
		#Declaration of arrays and variables
		litros = zeros(0)
		fechas = zeros(0)
		mini = zeros(0)
		maxi = zeros(0)
		index = zeros(0)
		d = len(p)*0.1
		
		if(len(p) > 10):	
			p2 = array_split(p, d)
			n = self.apply(mean, p2)
						
			#Round array of litros
			n = self.apply(around, n) 
			
			#Inserts the firts elements of the gas signal
			litros = append(litros, n[0])
			fechas = append(fechas, f[0])

			#Declaration of an counter
			c = 0

			for e in arange(len(n)-10):
				for i in range(1,11):
					if (fabs(n[e]-n[e+i]) > 5):
						c = c+1
						if (c > 10):
							index = append(index, e)
							mini = append(mini, n[e])
							maxi = append(maxi, n[e+i])
							c = 0
				
					else:
						c = 0

			if (len(index) > 1):
				for e in arange(len(index)-1):
					if (index[e+1]-index[e] <= 10 and fabs(maxi[e]-maxi[e+1]) < 1):
						litros = append(litros, min(mini[e], mini[e+1]))
						litros = append(litros, max(maxi[e], maxi[e+1]))
						fechas = append(fechas, f[int(index[e]*10)])
						fechas = append(fechas, f[int(index[e]*10.0)])
											
					if (index[e+1]-index[e] > 10):
						litros = append(litros, mini[e])
						litros = append(litros, maxi[e])
						fechas = append(fechas, f[int(index[e]*10)])
						fechas = append(fechas, f[int(index[e]*10)])
			
						litros = append(litros, mini[e+1])
						litros = append(litros, maxi[e+1])
						fechas = append(fechas, f[int(index[e+1]*10)])
						fechas = append(fechas, f[int(index[e+1]*10)])
			
			if (len(index) == 1): 
				litros = append(litros, mini[0])
				litros = append(litros, maxi[0])
				fechas = append(fechas, f[int(index[0]*10)])
				fechas = append(fechas, f[int(index[0]*10)])


		#Insert the last elements of the gas signal			
			litros = append(litros, n[len(n)-1])
			fechas = append(fechas, f[len(f)-1])
			consumos = diff(litros)
		
			#convirtiendo numpy arrays a python list
			l = litros.tolist()
			f = fechas.tolist()
			c = consumos.tolist()
			vector = []
			vector.append({'litros':l,'fechas':f,'consumos':c})
			return vector
			
		else:
			print "Arreglo de gasolina vacio"
		#return True

#=======================================================================

#g 	= Gasolina(1, 3, 2005)  #imei, idauto, anio
#res = g.gasolina_interpolacion(1376618400,1376698500)

#print res
