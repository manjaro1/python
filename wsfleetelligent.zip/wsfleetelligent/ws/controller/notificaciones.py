# -*- coding: utf-8 -*-
from xml.dom.minidom import parse, parseString
from ordereddict import OrderedDict
from urllib import urlencode
import unicodedata
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import requests
import re


class Sms():
    def __init__(self, datos, tipo):
        self.contenido = datos
        self.formato = tipo                
        self.texto = None
        self.destinatario = None
        self.fleeteligentkey = 'fl33t3l1g3nt2013'
        self.informe = None
    
    def enviar(self):		
			try:
				self.texto = self.contenido.getElementsByTagName('texto')[0].firstChild.data.encode("utf-8")
				self.destinatario = self.contenido.getElementsByTagName('destinatario')[0].firstChild.data
				
				if len(self.texto)<160 and len(self.destinatario)>9:
					parametros = OrderedDict([('cmd', 'send'), ('msg', self.texto), ('num', self.destinatario),('modo', 0),('clv', self.fleeteligentkey)])
					#exito = requests.get("https://201.122.147.1:8082/ws_sms_get.php", params=parametros, verify=False)
					exito = requests.get("https://192.168.50.105:8082/ws_sms_get.php", params=parametros, verify=False)							
					if (exito.status_code == requests.codes.ok):
						self.informe = "Mensaje enviado correctamente!"
						return True
					else:
						self.informe = "No pudo entregar el mensaje. Intente de nuevo!"
						return '1' #No pudo entregar el mensaje. Intente de nuevo
				else:
					self.informe = "Mensaje demasiado largo o destinatario no existe!"
					return '1'     #Mensaje demasiado largo o destinatario no existe
			except:
				self.informe = "No se pudo enviar el mensaje!"
				return '2'		   #Parametros incorrectos


class Email():
    def __init__(self, datos, tipo):
        self.contenido = datos
        self.formato = tipo
        self.texto = None
        self.destinatario = None
        self.informe = None
    
    def enviar(self):		
			try:
				emisor = "alarmas@fleetelligent.me"
				self.encabezado = self.contenido.getElementsByTagName('encabezado')[0].firstChild.data
				self.encabezado = unicodedata.normalize('NFKD', self.encabezado).encode('ascii','ignore')
				try:
					self.pie = self.contenido.getElementsByTagName('pie')[0].firstChild.data
					self.pie = unicodedata.normalize('NFKD', self.pie).encode('ascii','ignore')
				except:
					self.pie = ""
				try:
					subject = self.contenido.getElementsByTagName('subject')[0].firstChild.data
					subject = unicodedata.normalize('NFKD', subject).encode('ascii','ignore')
				except:
					subject = "Alarma! FleeTelligent"
					
				self.destinatario = self.contenido.getElementsByTagName('destinatario')[0].firstChild.data

				total_contenido = 0
				registro = ""
				contenido = self.contenido.getElementsByTagName('c')
				for medida in contenido:
					total_contenido = total_contenido + 1
					datos=medida.childNodes
					for dato in datos:
						if dato.nodeType == dato.TEXT_NODE:
							datodata = unicodedata.normalize('NFKD', dato.data).encode('ascii','ignore')
							registro = registro + str(datodata) + "<br>"

				correo = self.destinatario
				
				if re.match('^[(a-z0-9\_\-\.)]+@[(a-z0-9\_\-\.)]+\.[(a-z)]{2,4}$',correo.lower()):
					# Create message container - the correct MIME type is multipart/alternative.
					msg = MIMEMultipart('alternative')
					msg['Subject'] = subject
					msg['From'] = emisor
					msg['To'] = correo
					
					# Create the body of the message (a plain-text and an HTML version).
					text = "FleeTelligent Flotillas Inteligentes\nAviso"
					text = str(self.texto)
					html = """\
							<html>
							<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head>
							<body>
							<strong>
							<div align=center>
							%(encabezado)s
							</div>
							</strong><br>
							<p>
							%(contenido)s
							</p><br>
							<p><u>%(pie)s</u></p>
							</body>
							</html>
							"""%{'contenido':registro,'encabezado':self.encabezado,'pie':self.pie}
					# Record the MIME types of both parts - text/plain and text/html.
					part1 = MIMEText(text, 'plain')
					part2 = MIMEText(html, 'html')
					# Attach parts into message container.
					# According to RFC 2046, the last part of a multipart message, in this case
					# the HTML message, is best and preferred.
					msg.attach(part1)
					msg.attach(part2)

					#try:
						# sendmail function takes 3 arguments: sender's address, recipient's address
						# and message to send - here it is sent as one string.
						# Send the message via local SMTP server.
					mailServer = smtplib.SMTP('mail.fleetelligent.me',26)
					mailServer.ehlo()
					mailServer.starttls()
					mailServer.ehlo()
					mailServer.login("alarmas+fleetelligent.me","AL030613")
					mailServer.sendmail(emisor, correo, msg.as_string())
					mailServer.quit()
					self.informe = "Mensaje enviado correctamente!"
					return True
					#except:
					#	self.informe = "No pudo entregar el mensaje. Intente de nuevo!"
					#	return '1' #No pudo entregar el mensaje. Intente de nuevo
				else:
					self.informe = "Destinatario no existe!"
					return '1'     #Mensaje demasiado largo o destinatario no existe
			except:
				self.informe = "No se pudo enviar el mensaje!"
				return '2'		   #Parametros incorrectos
