# -*- coding: utf-8 -*-
from ws import app
import os
import subprocess
from flask import request, url_for, Response, jsonify, make_response, current_app
from xml.dom.minidom import parse, parseString
from functools import update_wrapper
from datetime import timedelta
from flaskext.uploads import *
from flask import send_file
from controller import vehiculos,usuarios,notificaciones, gasolina, upload
from libraries import security, responses
from flask.ext.sqlalchemy import SQLAlchemy

app.config.from_object(__name__)


def crossdomain(origin=None, methods=None, headers=None,
                max_age=21600, attach_to_all=True,
                automatic_options=True):
    if methods is not None:
        methods = ', '.join(sorted(x.upper() for x in methods))
    if headers is not None and not isinstance(headers, basestring):
        headers = ', '.join(x.upper() for x in headers)
    if not isinstance(origin, basestring):
        origin = ', '.join(origin)
    if isinstance(max_age, timedelta):
        max_age = max_age.total_seconds()

    def get_methods():
        if methods is not None:
            return methods

        options_resp = current_app.make_default_options_response()
        return options_resp.headers['allow']

    def decorator(f):
        def wrapped_function(*args, **kwargs):
            if automatic_options and request.method == 'OPTIONS':
                resp = current_app.make_default_options_response()
            else:
                resp = make_response(f(*args, **kwargs))
            if not attach_to_all and request.method != 'OPTIONS':
                return resp

            h = resp.headers

            h['Access-Control-Allow-Origin'] = origin
            h['Access-Control-Allow-Methods'] = get_methods()
            h['Access-Control-Max-Age'] = str(max_age)
            if headers is not None:
                h['Access-Control-Allow-Headers'] = headers
            return resp

        f.provide_automatic_options = False
        return update_wrapper(wrapped_function, f)
    return decorator
###

@app.route("/cross", methods=['POST'])
@crossdomain(origin='*')
def hello():
	#ss=str(request.form)
	f = request.files['imginspeccion']
	#data = json.loads(request.form.get('data'))
	#return responses.ok(str(request.form.get('imginspeccion')))
	return responses.ok('ok')


@app.route('/')
def api_root():	
	return 'Welcome - Fleeteligent Web Services PY'

@app.route('/vehiculos')
def api_vehiculos_list():
	flota = vehiculos.Vehiculo(None, 1)
	respuesta = flota.vehiculos_list()				
	if respuesta == True:
		datos = flota.valores
		return responses.ok(datos)
	else:
		datos = "No se pudo completar la solicitud!"
		return responses.not_acceptable(datos)
		
@app.route('/vehiculos/taxi/coordenadas/<imei>', methods = ['GET','POST'])
def api_vehiculo_coordenadas(imei):
	if request.headers['Content-Type'] == 'application/xml':
		contenido = request.data
		datos = parseString(contenido)		
		if 'licencia' in contenido:
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			subgrupo = security.encontrar_subgrupo_imei(imei)			
			valido = security.verificar_licencia(licencia,subgrupo)
			if valido == True:				
				taxi = vehiculos.Vehiculo(imei, 1)
				respuesta = taxi.obtener_coordenadas()				
				if respuesta == True:
					datos = taxi.valores
					return responses.ok(datos)
				else:
					datos = "No se pudo completar la solicitud!"
					return responses.not_acceptable(datos)
			else:
				return responses.unauthorized()
		else:
			return responses.bad_request()
	else:
		return responses.unsupported_media_type()

@app.route('/login', methods = ['POST'])
def api_login():
	from controller import movil
	amovil = movil.Movil(1)
	return amovil

@app.route('/vehiculos/coordenadas/<grupo>/<subgrupo>', methods = ['GET','POST'])
def api_grupo_coordenadas(grupo,subgrupo):
	# if request.headers['Content-Type'] == 'application/xml':
	# if request.headers['Content-Type'] == 'text/plain':
		# contenido = request.data
		# datos = parseString(contenido)
		# if 'data' in contenido and 'licencia' in contenido:
			# licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			#valido = security.verificar_licencia(licencia,subgrupo)
			valido = True
			if valido == True:
				grupo = int(grupo)
				subgrupo = int(subgrupo)
				flota = vehiculos.Vehiculo(None, 1)
				respuesta = flota.obtener_coordenadas_grupo(grupo,subgrupo)				
				if respuesta == True:
					datos = flota.valores
					return responses.ok(datos)
				else:
					datos = "No se pudo completar la solicitud!"
					return responses.not_acceptable(datos)
			else:
				return responses.unauthorized()
		# else:
			# return responses.bad_request()
	# else:
		# return responses.unsupported_media_type()		

@app.route('/vehiculos/datos/<operacion>', methods = ['POST'])
def api_vehiculo_operacion(operacion):
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)
			if 'data' in contenido and 'licencia' in contenido:
				licencia = datos.getElementsByTagName('licencia')[0].firstChild.data				
				api = 'api_vehiculo'
				valido = security.verificar_licencia(licencia,api)			
				if valido == True:
					unidad = vehiculos.Vehiculo(0,1)
					respuesta = unidad.datos_accion(operacion,datos)				
					if respuesta == True:
						datos = unidad.valores
						return responses.ok(datos)
					else:
						datos = "No se pudo completar la solicitud!"
						return responses.not_acceptable(datos)
				else:
					return responses.unauthorized()
			else:
				return responses.bad_request()
		except:
			return responses.internal_server_error()
	elif request.headers['Content-Type'] == 'application/json':
		try:
			contenido = request.json		
			if 'licencia' in contenido:
				licencia = contenido['licencia']
				api = 'api_vehiculo'
				valido = security.verificar_licencia(licencia,api)
				if valido == True:
					unidad = vehiculos.Vehiculo(0,1)
					respuesta = unidad.datos_accion(operacion,contenido)				
					if respuesta == True:
						datos = unidad.valores
						return responses.ok(datos)
					else:
						datos = "No se pudo completar la solicitud!"
						return responses.not_acceptable(datos)
				else:
					return responses.unauthorized()
			else:
				return responses.bad_request()
		except:
			return responses.internal_server_error()
	else:
		return responses.unsupported_media_type()
		
@app.route('/usuarios/datos/<operacion>', methods = ['POST'])
def api_usuarios_operacion(operacion):
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)
			if 'data' in contenido and 'licencia' in contenido:
				licencia = datos.getElementsByTagName('licencia')[0].firstChild.data							
				api = 'api_usuario'
				valido = security.verificar_licencia(licencia,api)			
				if valido == True:
					usuario = usuarios.Usuario(1)
					respuesta = usuario.datos_accion(operacion)				
					if respuesta == True:
						datos = usuario.valores
						return responses.ok(datos)
					else:
						datos = "No se pudo completar la solicitud!"
						return responses.not_acceptable(datos)
				else:
					return responses.unauthorized()
			else:
				return responses.bad_request()
		except:
			return responses.internal_server_error()
	elif request.headers['Content-Type'] == 'application/json':
		try:
			contenido = request.json		
			if 'licencia' in contenido:
				licencia = contenido['licencia']
				api = 'api_usuario'
				valido = security.verificar_licencia(licencia,api)
				if valido == True:
					usuario = usuarios.Usuario(1)
					respuesta = usuario.datos_accion(operacion)				
					if respuesta == True:
						datos = usuario.valores
						return responses.ok(datos)
					else:
						datos = "No se pudo completar la solicitud!"
						return responses.not_acceptable(datos)
				else:
					return responses.unauthorized()
			else:
				return responses.bad_request()
		except:
			return responses.internal_server_error()				
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS VEHICULO - OPERACIONES QUE SE REALIZAN CON VEHICULOS DE FLEETELLIGENT (CONSULTA,REGISTRO)
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DATOS QUE SE NECESITAN EN LA OPERACION A REALIZAR (CONSULTA: SERIE,IDCLIENTE)
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. SE REALIZA LA OPERACION SOLICITADA Y SE RETORNA EL STATUS DE LA CONSULTA
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/vehiculo/<consulta>' , methods = ['POST'])
def api_vehiculos(consulta):	
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_vehiculo'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				vehiculo = vehiculos.Vehiculo(datos,1)
				respuesta = vehiculo.datos_accion(consulta)
				datos = vehiculo.valores
				if respuesta == True:
					return responses.ok(datos)
				else:
					Switch = {1:responses.forbidden,\
							  2:responses.not_acceptable
							 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		except:
			return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS USUARIO - OPERACIONES QUE SE REALIZAN CON USUARIO DE FLEETELLIGENT (CONSULTA,REGISTRO)
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DATOS QUE SE NECESITAN EN LA OPERACION A REALIZAR (CONSULTA: USUARIO Y  PASSWORD)
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. SE REALIZA LA OPERACION SOLICITADA Y SE RETORNA EL STATUS DE LA CONSULTA
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/usuario/<consulta>' , methods = ['POST'])
def api_usuarios(consulta):	
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_usuario'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				usuario = usuarios.Usuario(datos,1)
				respuesta = usuario.datos_accion(consulta)
				datos = usuario.informe
				if respuesta == True:
					return responses.ok(datos)
				else:
					Switch = {1:responses.forbidden,\
							  2:responses.method_not_allowed
							 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		except:
			return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()

		
@app.route('/inspeccion/alta', methods = ['POST'])
def api_inspeccion_alta():
	if request.headers['Content-Type'] == 'application/xml':	
		try:			
			contenido = request.data
			datos = parseString(contenido)
			if 'data' in contenido and 'licencia' in contenido and 'values' in contenido:
				licencia = datos.getElementsByTagName('licencia')[0].firstChild.data							
				api = 'api_vehiculo'
				valido = security.verificar_licencia(licencia,api)			
				if valido == True:
					unidad = vehiculos.Vehiculo(0,1)
					respuesta = unidad.nueva_inspeccion(datos)				
					if respuesta == True:
						datos = unidad.valores
						return responses.ok(datos)
					else:
						datos = "No se pudo completar la solicitud!"
						return responses.not_acceptable(datos)
				else:
					return responses.unauthorized()
			else:
				return responses.bad_request()
		except:
			return False
	elif request.headers['Content-Type'] == 'application/json':
		try:
			contenido = request.json		
			if 'licencia' in contenido and 'values' in contenido:
				licencia = contenido['licencia']
				api = 'api_vehiculo'
				valido = security.verificar_licencia(licencia,api)
				if valido == True:
					#usuario = usuarios.Usuario(1)
					#respuesta = usuario.datos_accion(operacion)				
					#if respuesta == True:
					#	datos = usuario.valores
					#	return responses.ok(datos)
					#else:
					#	return responses.not_acceptable()
					return True
				else:
					return responses.unauthorized()
			else:
				return responses.bad_request()
		except:
			return responses.internal_server_error()				
	else:
		return responses.unsupported_media_type()
		

"""
_________________________________________________________________________________________________________
  WS INSPECCION - OPERACIONES QUE SE REALIZAN LAS INSPECCIONES DE VEHICULOS (AGREGAR,CONSULTAR,ELIMINAR)
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DATOS QUE SE NECESITAN EN LA OPERACION A REALIZAR
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. SE REALIZA LA OPERACION SOLICITADA Y SE RETORNA EL STATUS DE LA CONSULTA
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/inspeccion/<operacion>' , methods = ['POST'])
def api_inspeccion(operacion):	
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_vehiculo'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				inspeccion = vehiculos.Vehiculo(datos,1)
				respuesta = inspeccion.inspeccion_accion(operacion)
				datos = inspeccion.informe
				if respuesta == True:
					return responses.created(datos)
				else:
					Switch = {1:responses.forbidden,\
							  2:responses.not_acceptable,\
							  3:responses.method_not_allowed
							 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		except:
			return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS ASIGNACION - OPERACIONES QUE SE REALIZAN PARA ASIGNACIONES DE VEHICULOS (AGREGAR,CONSULTAR)
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DATOS QUE SE NECESITAN EN LA OPERACION A REALIZAR
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. SE REALIZA LA OPERACION SOLICITADA Y SE RETORNA EL STATUS DE LA CONSULTA
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/asignacion/<operacion>' , methods = ['POST'])
def api_asignacion(operacion):	
	if request.headers['Content-Type'] == 'application/xml':
		xy=1
		if xy==1:
		#try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_vehiculo'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				inspeccion = vehiculos.Vehiculo(datos,1)
				respuesta = inspeccion.asignacion_accion(operacion)
				datos = inspeccion.informe
				if respuesta == True:
					return responses.ok(datos)
				else:
					Switch = {1:responses.forbidden,\
							  2:responses.not_acceptable,\
							  3:responses.method_not_allowed
							 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		#except:
		#	return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()



"""
_________________________________________________________________________________________________________
  WS CHOFERES - OPERACIONES QUE SE REALIZAN SOBRE CHOFERES DE VEHICULOS (AGREGAR,CONSULTAR)
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DATOS QUE SE NECESITAN EN LA OPERACION A REALIZAR
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. SE REALIZA LA OPERACION SOLICITADA Y SE RETORNA EL STATUS DE LA CONSULTA
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/chofer/<operacion>' , methods = ['POST'])
def api_choferes(operacion):	
	if request.headers['Content-Type'] == 'application/xml':
		xy=1
		if xy==1:
		#try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_vehiculo'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				vehiculo = vehiculos.Vehiculo(datos,1)
				respuesta = vehiculo.choferes_accion(operacion)
				datos = vehiculo.informe
				if respuesta == True:
					return responses.ok(datos)
				else:
					Switch = {1:responses.forbidden,\
							  2:responses.not_acceptable,\
							  3:responses.method_not_allowed
							 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		#except:
		#	return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS CUESTIONARIO - OPERACIONES QUE SE REALIZAN SOBRE CUESTIONARIOS DE VEHICULOS (AGREGAR,CONSULTAR)
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DATOS QUE SE NECESITAN EN LA OPERACION A REALIZAR
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. SE REALIZA LA OPERACION SOLICITADA Y SE RETORNA EL STATUS DE LA CONSULTA
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/cuestionario/<operacion>' , methods = ['POST'])
def api_cuestionario(operacion):	
	if request.headers['Content-Type'] == 'application/xml':
		xy=1
		if xy==1:
		#try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_vehiculo'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				cuestionario = vehiculos.Vehiculo(datos,1)
				respuesta = cuestionario.cuestionario_accion(operacion)
				datos = cuestionario.informe
				if respuesta == True:
					return responses.ok(datos)
				else:
					Switch = {1:responses.forbidden,\
							  2:responses.not_acceptable,\
							  3:responses.method_not_allowed
							 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		#except:
		#	return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS SMS - ENVIO DE MENSAJES A NUMEROS DE CELULAR
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DESTINATARIO(TELEFONO),TEXTO(CONTENIDO DEL MENSAJE)
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. POSTERIORMENTE SE ENVIA EL MENSAJE CON LA CLAVE AGIGNADA A FLEETELIGENT
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/sms/nuevo' , methods = ['POST'])
def api_sms():	
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_sms'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				mensaje = notificaciones.Sms(datos,1)
				respuesta = mensaje.enviar()
				datos = mensaje.informe			
				if respuesta == True:					
					return responses.ok(datos)
				else:					
					Switch = {1:responses.sms_send_error,\
						  2:responses.not_acceptable
						 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		except:
			return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Sms json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS EMAIL - ENVIO DE MENSAJES DE EMAIL A CUENTAS DE CORREO REGISTRADAS
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DESTINATARIO(CORREO),TEXTO(CONTENIDO DEL MENSAJE)
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. POSTERIORMENTE SE ENVIA EL MENSAJE CON LA CLAVE AGIGNADA A FLEETELIGENT
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/email/nuevo' , methods = ['POST'])
def api_email():	
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_sms'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				mensaje = notificaciones.Email(datos,1)
				respuesta = mensaje.enviar()
				datos = mensaje.informe			
				if respuesta == True:					
					return responses.ok(datos)
				else:					
					Switch = {1:responses.email_send_error,\
						  2:responses.not_acceptable
						 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		except:
			return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Email json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS EMAIL - ENVIO DE MENSAJES DE EMAIL A CUENTAS DE CORREO REGISTRADAS
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,DESTINATARIO(CORREO),TEXTO(CONTENIDO DEL MENSAJE)
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. POSTERIORMENTE SE ENVIA EL MENSAJE CON LA CLAVE AGIGNADA A FLEETELIGENT
_________________________________________________________________________________________________________
"""

@app.route('/testinterpolacion/<imei>',methods=['GET'])
def api_testinterpolacion(imei):
  print 'holamundo'
  interpolacion = gasolina.Gasolina(imei)
  contenido= '<data><licencia>1</licencia><autoid>5</autoid><fecha_i>1379394000</fecha_i><fecha_f>1379653199</fecha_f><anio>2013</anio></data>'
  datos = parseString(contenido)
  interpolacion.gasolina_interpolacion(datos)
  return datos.getElementsByTagName('licencia')[0].firstChild.data

@app.route('/fleetelligent/vehiculos/interpolacion/<imei>' , methods = ['POST'])
def api_interpolacion(imei):	
	if request.headers['Content-Type'] == 'application/xml':
		try:
			contenido = request.data
			datos = parseString(contenido)			
			licencia = datos.getElementsByTagName('licencia')[0].firstChild.data
			api = 'api_vehiculo'
			valido = security.verificar_licencia(licencia,api)
			if valido == True:
				interpolacion = gasolina.Gasolina(imei)
				respuesta = interpolacion.gasolina_interpolacion(datos)
				#return respuesta
				datos = interpolacion.informe			
				if respuesta == True:					
					return responses.ok(datos)
				else:					
					Switch = {1:responses.method_not_allowed,\
						  2:responses.not_acceptable
						 }
					case=int(respuesta)
					resultado = Switch[case](datos)
					return resultado
			else:
				return responses.unauthorized()
		except:
			return responses.bad_request()
	elif request.headers['Content-Type'] == 'application/json':
		return 'Email json - No implementado'
	else:
		return responses.unsupported_media_type()


"""
_________________________________________________________________________________________________________
  WS UPLOAD IMAGENES - RECEPCION DE IMAGENES POR TIPO(INSPECCION,...), SEGMENTO (1-FRONTAL,2-LATERAL), IDENTIFICADOR DE IMAGEN
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,IMAGEN,ID INSPECCION,TIPO IMAGEN
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. POSTERIORMENTE SE ENVIA EL MENSAJE CON LA CLAVE AGIGNADA A FLEETELIGENT
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/uploads/img/<tipo>/<segmento>/<id>' , methods = ['GET','POST'])
@crossdomain(origin='*')
def upload_image(tipo,segmento,id):
	xy = 1
	if xy ==1:
		if request.method == 'POST':
			if (str(tipo)=='inspeccion'):
				#ruta = '/home/fleetelligent/fleet_public/inspeccion/'
				ruta = '/home/jac/fleetelligent/fleet_public/inspeccion/'
				areas = {'1':'frontal/','2':'lateral/'}
				seccion = areas[str(segmento)]
				idinspeccion = str(id)		#Obtener idinspeccion del url- para nombre del archivo
				ruta = ruta + seccion + str(idinspeccion) + ".jpg"
				datos = {'ruta':str(ruta),'idinspeccion':str(idinspeccion),'idtipoimagen':str(segmento)}
				up = upload.Upload(datos)
				respuesta = up.existe_img()
				if(respuesta):	#Ya existe imagen
					#Eliminar la existente 
					try:
						os.remove(str(ruta))
					except:
						s = 'Eliminado'
					#Guardar la nueva imagen y actualizar sus datos
					f = request.files['imginspeccion']
					try:
						f.save(str(ruta))
						update_img = up.update_ruta_img(respuesta)
						return responses.ok('Imagen actualizada')
					except:
						return responses.not_acceptable('No se ha podido actualizar el archivo')
				else:					#No existe imagen
					#Guardar la nueva imagen y crear su registro
					f = request.files['imginspeccion']
					try:
						f.save(str(ruta))
						save_img = up.nueva_ruta_img()
						if save_img:
							return responses.ok('Imagen almacenada')
						else:
							return responses.bad_request()
					except:
						return responses.not_acceptable('No se ha podido guardar el archivo')
	
	
	
"""
_________________________________________________________________________________________________________
  WS GET IMAGENES - DEVOLUCION DE IMAGENES POR TIPO(INSPECCION,...), SEGMENTO (1-FRONTAL,2-LATERAL), IDENTIFICADOR DE IMAGEN
  METODO DISPONIBLE PARA PASE DE PARAMETROS: POST
  PARAMETROS XML: LICENCIA,IMAGEN,ID INSPECCION,TIPO IMAGEN
  FORMATO DE RESPUESTA: JSON
  SE VALIDA LICENCIA Y ACCESO AL API. POSTERIORMENTE SE ENVIA EL MENSAJE CON LA CLAVE AGIGNADA A FLEETELIGENT
_________________________________________________________________________________________________________
"""
@app.route('/fleetelligent/get/img/<tipo>/<segmento>/<id>' , methods = ['GET','POST'])
@crossdomain(origin='*')
def get_image(tipo,segmento,id):
    if (str(tipo)=='inspeccion'):
		try:
			#ruta = '/home/fleetelligent/fleet_public/inspeccion/'
			ruta = '/home/jac/fleetelligent/fleet_public/inspeccion/'
			areas = {'1':'frontal/','2':'lateral/'}
			seccion = areas[str(segmento)]
			idinspeccion = str(id)	#Obtener idinspeccion del url- para nombre del archivo
			datos = {'ruta':str(ruta),'idinspeccion':str(idinspeccion),'idtipoimagen':str(segmento)}
			up = upload.Upload(datos)
			respuesta = up.get_ruta_img(datos)
			if(respuesta):	#Ya existe imagen
				return send_file(respuesta, mimetype='image/jpg')
			else:
				return responses.not_acceptable('No se encontraron conincidencias')
		except:
			return responses.bad_request()

@app.route('/whatsapp/nuevo', methods = ['GET','POST'])
@crossdomain(origin='*')
def mensaje_whatsapp():
	if request.json:
		mydata = request.json
		numero = request.json["numero"]
		mensaje = request.json["mensaje"]
		# subprocess.call(['python' ,'yowsup-cli', '-c', '~/yowsup-master/src/config.example', '-w', '-s', numero, mensaje])
		return responses.ok('Mensaje enviado')
	else:
		return responses.bad_request()

app.secret_key = 'F1Tc54g/2yVS~YAQ!nnE]LMY/,?NT'
