# -*- coding: utf-8 -*-
from ws import app
from flask import request,jsonify

#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 200.- OK
#	VALOR DE RETORNO JSON (SOLICITUD EXITOSA)
#_____________________________________________________________________________________#
@app.errorhandler(200)
def ok(datos):
    message = {
            'status': 200,
            'message': 'Ok',
            'data' : datos,
    }
    resp = jsonify(message)
    resp.status_code = 200
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 201.- CREATED
#	VALOR DE RETORNO JSON (ELEMENTO CREADO)
#_____________________________________________________________________________________#
@app.errorhandler(201)
def created(datos):
    message = {
            'status': 201,
            'message': 'Created',
            'data':datos
    }
    resp = jsonify(message)
    resp.status_code = 201
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 202.- ACCEPTED
#	VALOR DE RETORNO JSON (SOLICITUD ACEPTADA)
#_____________________________________________________________________________________#
@app.errorhandler(202)
def accepted(datos):
    message = {
            'status': 202,
            'message': 'Accepted',
            'id': datos['userid'],
            'token' : datos['token'],
            'estado' : datos['estado']
    }
    resp = jsonify(message)
    resp.status_code = 202
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 210.- SMS_SEND_ERROR
#	VALOR DE RETORNO JSON (ERROR AL ENVIAR EL MENSAJE)
#_____________________________________________________________________________________#
@app.errorhandler(210)
def sms_send_error(datos):
    message = {
            'status': 210,
            'message': 'Sms send error',
            'data' : datos,
    }
    resp = jsonify(message)
    resp.status_code = 210
    return resp


#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 211.- EMAIL_SEND_ERROR
#	VALOR DE RETORNO JSON (ERROR AL ENVIAR EL MENSAJE)
#_____________________________________________________________________________________#
@app.errorhandler(211)
def email_send_error(datos):
    message = {
            'status': 211,
            'message': 'Email send error',
            'data' : datos,
    }
    resp = jsonify(message)
    resp.status_code = 211
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 315.- VINCULADO
#	VALOR DE RETORNO JSON (CALORI VINCULADO)
#_____________________________________________________________________________________#
@app.errorhandler(315)
def vinculated(datos):
    message = {
            'status': 315,
            'message': 'Vinculado',
            'data' : datos,
	}
    resp = jsonify(message)
    resp.status_code = 315
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ESTADO 316.- NO VINCULADO
#	VALOR DE RETORNO JSON (CALORI NO VINCULADO)
#_____________________________________________________________________________________#
@app.errorhandler(316)
def not_vinculated(error=None):
    message = {
            'status': 316,
            'message': 'No Vinculado.',
    }
    resp = jsonify(message)
    resp.status_code = 316
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 400.- BAD REQUEST
#	VALOR DE RETORNO JSON (SOLICITUD INCORRECTA)
#_____________________________________________________________________________________#
@app.errorhandler(400)
def bad_request(error=None):
    message = {
            'status': 400,
            'message': 'Bad Request',
    }
    resp = jsonify(message)
    resp.status_code = 400
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 401.- UNAUTHORISED
#	VALOR DE RETORNO JSON (SIN AUTORIZACION)
#_____________________________________________________________________________________#
@app.errorhandler(401)
def unauthorized(error=None):
    message = {
            'status': 401,
            'message': 'Unauthorized',
    }
    resp = jsonify(message)
    resp.status_code = 401
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 402.- PAYMENT REQUIRED
#	VALOR DE RETORNO JSON (REQUIERE PAGO)
#_____________________________________________________________________________________#
@app.errorhandler(402)
def payment_required(error=None):
    message = {
            'status': 402,
            'message': 'Payment Required',
    }
    resp = jsonify(message)
    resp.status_code = 402
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 403.- FORBIDDEN
#	VALOR DE RETORNO JSON (ACCESO RESTRINGIDO)
#_____________________________________________________________________________________#
@app.errorhandler(403)
def forbidden(datos):
    message = {
            'status': 403,
            'message': 'Forbidden/Access Denied',
            'data' : datos,
    }
    resp = jsonify(message)
    resp.status_code = 403
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 404.- NOT FOUND
#	VALOR DE RETORNO JSON (PAGINA NO ENCONTRADA)
#_____________________________________________________________________________________#
@app.errorhandler(404)
def not_found(error=None):
    message = {
            'status': 404,
            'message': 'Not Found: ' + request.url,
    }
    resp = jsonify(message)
    resp.status_code = 404
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 405.- METHOD NOT ALLOWED
#	VALOR DE RETORNO JSON (CONSULTA NO PERMITIDA)
#_____________________________________________________________________________________#
@app.errorhandler(405)
def method_not_allowed(datos):
    message = {
            'status': 405,
            'message': 'Method Not Allowed',
            'data' : datos,            
    }
    resp = jsonify(message)
    resp.status_code = 405
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 406.- NOT ACCEPTABLE
#	VALOR DE RETORNO JSON (CONSULTA NO ACEPTADA)
#_____________________________________________________________________________________#
@app.errorhandler(406)
def not_acceptable(datos):
    message = {
            'status': 406,
            'message': 'No Registrado. Verifique parametros/datos de acceso',
            'data' : datos,
    }
    resp = jsonify(message)
    resp.status_code = 406
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 415.- UNSUPPORTED MEDIA TYPE
#	VALOR DE RETORNO JSON (TIPO DE DATO NO VALIDO)
#_____________________________________________________________________________________#
@app.errorhandler(415)
def unsupported_media_type(error=None):
    message = {
            'status': 415,
            'message': 'Unsupported Media Type',
    }
    resp = jsonify(message)
    resp.status_code = 415
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 500.- INTERNAL SERVER ERROR
#	VALOR DE RETORNO JSON (ERROR DEL SERVIDOR)
#_____________________________________________________________________________________#
@app.errorhandler(500)
def internal_server_error(error=None):
    message = {
            'status': 500,
            'message': 'Internal Server Error',
    }
    resp = jsonify(message)
    resp.status_code = 500
    return resp

#_____________________________________________________________________________________#
#	CODIGO DE ERROR 501.- NOT IMPLEMENTED
#	VALOR DE RETORNO JSON (NO IMPLEMENTADO)
#_____________________________________________________________________________________#
@app.errorhandler(501)
def not_implemented(error=None):
    message = {
            'status': 501,
            'message': 'Not Implemented',
    }
    resp = jsonify(message)
    resp.status_code = 501
    return resp

