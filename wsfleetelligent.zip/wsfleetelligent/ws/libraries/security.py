# -*- coding: utf-8 -*-
import hmac
import hashlib
import binascii
from hashlib import sha1,md5
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
from flask import current_app
from ws.model import database as d
from ws.helper import subgrupos as s

def verificar_licencia(licencia,acceso):
	try:
		tabla = 'licencias'
		id_u = ''
		campos = ''	
		where = " WHERE clave='" + str(licencia) + "' AND " + str(acceso) + "= TRUE"
		db = d.Database(tabla,id_u,campos)
		respuesta = db.consultar(where)
		return respuesta	
	except:
		return False

def encontrar_subgrupo_imei(imei):
	tabla = 'imei_id_catalog i,vehiculo v'
	id_u = ''
	campos = 'v.id_subcategoria'
	# select v.id_subcategoria from imei_id_catalog i, vehiculo v where i.imei='861785003720343' and v.id_imei=i.id
	where = " WHERE i.imei='" + str(imei) + "' AND v.id_imei=i.id"
	db = d.Database(tabla,id_u,campos)
	subgrupoid = db.consultar(where)
	subgrupo = s.Subgrupo()
	s_imei = subgrupo.actual(subgrupoid)
	return s_imei
	
def encontrar_subgrupo_placa(placa):
	try:
		tabla = 'vehiculo'
		id_u = ''
		campos = 'id_subcategoria'	
		where = " WHERE placa='" + str(placa) + "'"
		db = d.Database(tabla,id_u,campos)
		reespuesta = db.get(where)
		if respuesta == True:
			subgrupoid = db.rows[0]['id_subcategoria']
			subgrupo = s.Subgrupo()
			s_placa = subgrupo.actual(subgrupoid)
			return s_placa
		else:
			return 'grupox'	
	except:
		return 'grupox'

def aes_encrypt(plain_text, key):
	mode = AES.MODE_CFB
	encryptor = AES.new(key, mode)
	ciphertext = encryptor.encrypt(plain_text)
	return ciphertext


def aes_decrypt(encrypted_text, key):
	#BLOCK_SIZE = 16
	#PADDING = '{'
	#pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
	#DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING)
	mode = AES.MODE_CFB
	cipher = AES.new(key, mode)
	decoded = cipher.decrypt(encrypted_text)
	plain_text=decoded.replace("\n", '')		
	return str(plain_text)
	
def to_hash(pwd, contrasenia):
	salt = contrasenia[:10]
	cadena=hashlib.sha1(salt + pwd)
	sha1_password=cadena.hexdigest()
	sha_str = sha1_password[:-10]
	return salt + sha_str

