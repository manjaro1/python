# -*- coding: utf-8 -*-

class Subgrupo:
	catalogo_subgrupos = {1:'subgrupo1',\
						  2:'subgrupo2',\
						  3:'subgrupo3'			   
						 }
	
	def __init__(self):
		self.subgrupo = None
		
	def actual(self, subgrupoid):
		self.subgrupo = self.catalogo_subgrupos[int(subgrupoid)]
		return self.subgrupo
		
