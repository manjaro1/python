# -*- coding: utf-8 -*-
import pg
import sys

class Database:
	tabla = {'nombre':'','id':'','campos':[]}
	
	def __init__(self,tabla,id_,campos):
		self.tabla['nombre'] = tabla
		self.tabla['id'] = id_
		self.tabla['campos'] = campos
		try:
			self.conexion = pg.connect('fleetelligent', '127.0.0.1', 5432, None, None, 'postgres', 'abc1234')
		except:
			return False
	
	def agregar(self,values):
		conn = self.conexion
		sentencia = "INSERT INTO "+self.tabla['nombre']+"("+self.tabla['campos']+") VALUES("+values+")"				
		try:
			resultado=conn.query(sentencia)
			conn.close()
			return True
		except:
			return False		

	def add(self,values,returning):
		conn = self.conexion
		sentencia = "INSERT INTO "+self.tabla['nombre']+"("+self.tabla['campos']+") VALUES("+values+")" + returning
		try:
			resultado=conn.query(sentencia)
			self.row = resultado.dictresult()
			conn.close()
			return True
		except:
			return False

		
	def modificar(self,datos,where):
		conn = self.conexion	
		sentencia = "UPDATE "+self.tabla['nombre']+ " SET " + str(datos) + str(where)
		try:
			resultado=conn.query(sentencia)
			conn.close()
			if resultado.ntuples() > 0:				
				return True
			else:
				return False
		except:
			return False
	
	def eliminar(self,id_):
		conn=conecta_db(self)	
		conn.close
		return resultado
	
	def consultar(self,where):
		conn = self.conexion
		exito = False
		sentencia = "SELECT * FROM "+ self.tabla['nombre'] + where
		try:
			resultado=conn.query(sentencia)
			conn.close()
			if resultado.ntuples() > 0:
				exito = True
		except:
			exito = False
		return exito
	
	def get(self,where):
		conn = self.conexion	
		sentencia = "SELECT "+self.tabla['campos']+" FROM "+ self.tabla['nombre'] + where
		try:
			resultado=conn.query(sentencia)
			conn.close()
			if resultado.ntuples() > 0:
				self.numfilas = resultado.ntuples()
				self.rows = resultado.dictresult()
				return True
			else:
				return False
		except:
			return False		


	def query(self, query):
		conn = self.conexion	
		try:
			resultado = conn.query(query)
			conn.close()
			if resultado.ntuples() > 0:
				self.numfilas = resultado.ntuples()
				self.rows = resultado.dictresult()
				return True
			else:
				return False
		except:
			return False


